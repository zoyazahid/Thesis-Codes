"""Step 14 (CPU) - thesis figures built from the results files:
  figures/f1_comparison.png            Pipeline A (reported / corrected) vs Pipeline B depression F1
  figures/ablation_feature_blocks.png  Pipeline B feature-block ablation
  figures/c2_6de_confusion.png         6DE projection vs human GoEmotions labels
Run after steps 1, 2 and 4."""
import json, numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt

# Pipeline A values are taken from its run logs (SMOTE before CV) and from the same pipeline re-run with
# SMOTE inside the folds.
A_REPORTED, A_REPORTED_SD, A_CORRECTED, A_CORRECTED_SD = 0.8206, 0.0579, 0.4754, 0.1297

fs = json.load(open("results/final_summary.json"))
labels = ["A: reported\n(SMOTE before CV)", "A: same pipeline,\nSMOTE inside folds", "B: best model,\n5x5 CV", "B: held-out\ntest (47)"]
vals = [A_REPORTED, A_CORRECTED, fs["best_cv_config"]["cv_f1_mean"], fs["heldout_test"]["f1"]]
fig, ax = plt.subplots(figsize=(8, 4.3))
ax.bar(labels, vals, color=["#C0392B", "#9AA5B1", "#4C72B0", "#2E7D32"],
       yerr=[A_REPORTED_SD, A_CORRECTED_SD, fs["best_cv_config"]["cv_f1_std"], 0], capsize=4)
lo, hi = fs["heldout_test"]["f1_95ci"]
ax.errorbar(3, vals[3], yerr=[[vals[3] - lo], [hi - vals[3]]], fmt="none", ecolor="black", capsize=4)
for i, v in enumerate(vals):
    ax.text(i - 0.22, v / 2, f"{v:.3f}", ha="center", va="center", fontsize=11, color="white", fontweight="bold")
ax.text(0.22, 0.06, "invalid\n(leakage)", ha="center", color="white", fontsize=9)
ax.set_ylim(0, 1); ax.set_ylabel("Binary F1 (depressed class)")
ax.set_title("Depression detection on DAIC-WOZ: Pipeline A vs Pipeline B (error bars: CV SD; test: 95% CI)", fontsize=10)
ax.spines[["top", "right"]].set_visible(False); fig.tight_layout(); fig.savefig("figures/f1_comparison.png", dpi=200)

g = pd.read_csv("results/experiments_classification.csv")
b = g.sort_values("cv_f1_mean", ascending=False).groupby("features").head(1).sort_values("cv_f1_mean")
SHORT = {"EMB": "Embed", "EMO": "Emotion", "LING": "Ling", "AU": "AU", "LLM": "LLaMA"}
fig, ax = plt.subplots(figsize=(8, 5.6))
ax.barh([" + ".join(SHORT[x] for x in f.split("+")) for f in b.features], b.cv_f1_mean, xerr=b.cv_f1_std, color="#4C72B0", capsize=3)
ax.axvline(A_CORRECTED, ls="--", color="#C44E52", label=f"Corrected Pipeline A baseline (F1 {A_CORRECTED:.3f})")
ax.set_xlabel("Binary F1, 5x5 repeated CV (mean ± SD)"); ax.set_title("Feature-block ablation (best model per set)")
ax.legend(loc="lower right", fontsize=8, framealpha=1); fig.tight_layout(); fig.savefig("figures/ablation_feature_blocks.png", dpi=200)

v6 = json.load(open("results/c1_6de_validation.json"))
SIX = ["sad", "happy", "fear", "anger", "surprise", "love"]
cm = np.array(v6["thesis method (top-3 labels)"]["confusion_single"]); cmn = cm / cm.sum(1, keepdims=True)
fig, ax = plt.subplots(figsize=(5.6, 4.6)); ax.imshow(cmn, cmap="Blues", vmin=0, vmax=1)
ax.set_xticks(range(6), SIX); ax.set_yticks(range(6), SIX)
for i in range(6):
    for j in range(6):
        ax.text(j, i, f"{cmn[i, j]:.2f}\n(n={cm[i, j]})", ha="center", va="center", fontsize=7, color="white" if cmn[i, j] > .5 else "black")
ax.set_xlabel("6DE predicted from RoBERTa (thesis projection)"); ax.set_ylabel("6DE from human GoEmotions labels")
ax.set_title("6DE projection vs human annotation (GoEmotions test)", fontsize=10)
fig.tight_layout(); fig.savefig("figures/c2_6de_confusion.png", dpi=200)
print("figures written to figures/")
