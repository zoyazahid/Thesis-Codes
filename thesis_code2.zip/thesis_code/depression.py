"""
depression.py - Pipeline B, Component 5: leakage-free depression detection on DAIC-WOZ (CPU).
Used by 02_depression_detection_CPU.py, 03_tfidf_baselines_CPU.py and 04_nested_cv_CPU.py.

Feature blocks (session level, participant utterances only):
  EMO  28-class GoEmotions statistics (mean / std / max / dominant share)
  EMB  all-mpnet-base-v2 sentence embeddings (session mean; PCA inside each training fold)
  LING psycholinguistic markers (pronouns, absolutist words, negations, affect words, verbosity)
  AU   OpenFace action-unit statistics (mean / std of 14 AUs)
  LLM  zero-shot LLaMA-3 PHQ-8 item scores (used if data_cache/llm_phq_features.csv exists)
Protocol: every preprocessing step (imputation, scaling, PCA, SMOTE) inside sklearn/imblearn
pipelines; 5x5 repeated stratified CV on 142 train+dev sessions; model chosen on CV F1 only;
threshold from out-of-fold training predictions; single evaluation on the official dev split and
on the held-out 47-session AVEC 2017 test split; permutation test; bootstrap CI; PHQ-8 regression.
Session features are cached in data_cache/ (emo_*.parquet, emb_*.parquet).
"""
import argparse, json, os, re, sys, warnings
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
SEED = 42
np.random.seed(SEED)

CKPT_REPO = "zoyazahid152/thesis-checkpoints"
DATA_REPO = "zoyazahid152/diacwoz-dataset"
CACHE = "data_cache"
RES = "results"
FIG = "figures"
for d in (CACHE, RES, FIG):
    os.makedirs(d, exist_ok=True)

EMO_MODEL = "SamLowe/roberta-base-go_emotions"
EMB_MODEL = "sentence-transformers/all-mpnet-base-v2"

# ─────────────────────────────────────────────────────────────────────────────
# 1. DATA
# ─────────────────────────────────────────────────────────────────────────────
def _hf(filename, repo, repo_type):
    for folder in ("data", CACHE):
        local = os.path.join(folder, filename)
        if os.path.exists(local):
            return local
    from huggingface_hub import hf_hub_download
    from common import hf_token
    return hf_hub_download(repo_id=repo, filename=filename, repo_type=repo_type,
                           token=hf_token(), local_dir="data")

def _norm_label_cols(df):
    df = df.copy()
    df.columns = df.columns.str.strip()
    ren = {}
    for c in df.columns:
        lc = c.lower()
        if lc in ("participant_id", "participantid", "id", "subject_id"):
            ren[c] = "session_id"
        elif lc in ("phq8_binary", "phq_binary"):
            ren[c] = "PHQ8_Binary"
        elif lc in ("phq8_score", "phq_score"):
            ren[c] = "PHQ8_Score"
    return df.rename(columns=ren)

def load_data(fake=False):
    """Returns utterance-level train(+dev) and test dataframes, session labels, AU table."""
    if fake:
        return _fake_data()
    tr = pd.read_csv(_hf("clean_transcripts.csv", CKPT_REPO, "model"))
    au = pd.read_csv(_hf("clean_au_features.csv", CKPT_REPO, "model"))
    try:
        te = pd.read_csv(_hf("test_transcripts.csv", CKPT_REPO, "model"))
    except Exception as e:
        print(f"[warn] no test_transcripts.csv ({e}); test-set evaluation skipped")
        te = pd.DataFrame(columns=["session_id", "text"])

    lab_tr = (tr.groupby("session_id")
                .agg(PHQ8_Binary=("PHQ8_Binary", "first"),
                     PHQ8_Score=("PHQ8_Score", "first"),
                     split=("split", "first"))
                .dropna(subset=["PHQ8_Binary"]).reset_index())
    lab_te = None
    for fn in ("full_test_split.csv", "test_split_Depression_AVEC2017.csv"):
        try:
            d = _norm_label_cols(pd.read_csv(_hf(fn, DATA_REPO, "dataset")))
            if "PHQ8_Binary" in d.columns:
                lab_te = d[["session_id", "PHQ8_Binary"] +
                           (["PHQ8_Score"] if "PHQ8_Score" in d.columns else [])]
                print(f"Test labels from {fn}: {len(lab_te)} sessions")
                break
        except Exception:
            pass
    if lab_te is None:
        print("[warn] test labels not found; test-set evaluation skipped")
        lab_te = pd.DataFrame(columns=["session_id", "PHQ8_Binary", "PHQ8_Score"])
    lab_te = lab_te.assign(split="test")

    te = te[["session_id", "text"]].dropna()
    te = te[te.session_id.isin(lab_te.session_id)]
    # test_transcripts may hold the same session twice ('test' and 'full_test')
    te = te.drop_duplicates()
    tr = tr[["session_id", "text"]].dropna()
    return tr, te, lab_tr, lab_te, au

def _fake_data():
    rng = np.random.default_rng(0)
    vocab = ("i me my feel tired sad happy good always never nothing work family sleep "
             "friends fun hard love great really think go home").split()
    rows, labs = [], []
    for sid in range(300, 492):
        y = int(rng.random() < 0.3)
        for _ in range(rng.integers(20, 60)):
            w = rng.choice(vocab, size=rng.integers(5, 20))
            if y and rng.random() < 0.3:
                w = np.append(w, ["tired", "never", "i"])
            rows.append((sid, " ".join(w)))
        labs.append((sid, y, float(rng.integers(10, 24) if y else rng.integers(0, 10))))
    utt = pd.DataFrame(rows, columns=["session_id", "text"])
    lab = pd.DataFrame(labs, columns=["session_id", "PHQ8_Binary", "PHQ8_Score"])
    lab["split"] = np.where(lab.session_id < 400, "train",
                            np.where(lab.session_id < 445, "dev", "test"))
    lab_tr, lab_te = lab[lab.split != "test"], lab[lab.split == "test"]
    au = pd.DataFrame({"session_id": lab_tr.session_id,
                       **{f"AU{i:02d}_r_mean": rng.normal(size=len(lab_tr)) for i in range(1, 15)}})
    return (utt[utt.session_id.isin(lab_tr.session_id)], utt[utt.session_id.isin(lab_te.session_id)],
            lab_tr.reset_index(drop=True), lab_te.reset_index(drop=True), au)

# ─────────────────────────────────────────────────────────────────────────────
# 2. FEATURES (utterance level -> session level), cached
# ─────────────────────────────────────────────────────────────────────────────
def emotion_features(utt, tag, fake=False):
    path = os.path.join(CACHE, f"emo_{tag}.parquet")
    if os.path.exists(path):
        return pd.read_parquet(path)
    if fake:
        probs = np.random.default_rng(1).dirichlet(np.ones(28), size=len(utt))
        labels = [f"e{i}" for i in range(28)]
    else:
        from transformers import pipeline
        print(f"[EMO] scoring {len(utt)} utterances with {EMO_MODEL} on CPU ...")
        pipe = pipeline("text-classification", model=EMO_MODEL, top_k=None,
                        truncation=True, max_length=128, device=-1)
        out = pipe(utt.text.astype(str).tolist(), batch_size=32)
        labels = sorted(d["label"] for d in out[0])
        probs = np.array([[{d["label"]: d["score"] for d in o}[l] for l in labels] for o in out])
    df = pd.DataFrame(probs, columns=[f"p_{l}" for l in labels])
    df["session_id"] = utt.session_id.values
    df["dominant"] = df[[f"p_{l}" for l in labels]].values.argmax(1)
    g = df.groupby("session_id")
    pcols = [f"p_{l}" for l in labels]
    feat = pd.concat([g[pcols].mean().add_prefix("emo_mean_"),
                      g[pcols].std().fillna(0).add_prefix("emo_std_"),
                      g[pcols].max().add_prefix("emo_max_")], axis=1)
    dom = (pd.crosstab(df.session_id, df.dominant, normalize="index")
             .reindex(columns=range(len(labels)), fill_value=0))
    dom.columns = [f"emo_dom_{labels[i]}" for i in dom.columns]
    feat = feat.join(dom).reset_index()
    feat.to_parquet(path)
    return feat

def embedding_features(utt, tag, fake=False):
    path = os.path.join(CACHE, f"emb_{tag}.parquet")
    if os.path.exists(path):
        return pd.read_parquet(path)
    if fake:
        E = np.random.default_rng(2).normal(size=(len(utt), 64))
    else:
        from sentence_transformers import SentenceTransformer
        print(f"[EMB] embedding {len(utt)} utterances with {EMB_MODEL} on CPU ...")
        m = SentenceTransformer(EMB_MODEL, device="cpu")
        E = m.encode(utt.text.astype(str).tolist(), batch_size=64,
                     show_progress_bar=True, normalize_embeddings=True)
    df = pd.DataFrame(E, columns=[f"emb_{i}" for i in range(E.shape[1])])
    df["session_id"] = utt.session_id.values
    feat = df.groupby("session_id").mean().reset_index()
    feat.to_parquet(path)
    return feat

FPS = {"i", "me", "my", "mine", "myself"}
FPP = {"we", "us", "our", "ours", "ourselves"}
ABSOLUTIST = {"always", "never", "nothing", "everything", "completely", "totally", "entire",
              "entirely", "constantly", "definitely", "whole", "every", "all", "absolutely",
              "nobody", "everyone", "anything"}
NEGATION = {"not", "no", "never", "cannot", "nobody", "none", "nor", "neither", "nothing"}
NEG_AFF = {"sad", "tired", "depressed", "depression", "alone", "lonely", "hopeless", "worthless",
           "anxious", "anxiety", "stress", "stressed", "hate", "cry", "crying", "bad", "hard",
           "difficult", "worried", "worry", "upset", "angry", "pain", "hurt", "lost", "afraid",
           "scared", "miserable", "exhausted", "guilty", "useless", "empty", "therapy", "therapist"}
POS_AFF = {"happy", "good", "great", "love", "fun", "enjoy", "proud", "excited", "glad",
           "wonderful", "amazing", "nice", "relaxed", "calm", "best", "awesome", "fantastic"}

def linguistic_features(utt):
    rows = []
    for sid, g in utt.groupby("session_id"):
        toks = [t.split() for t in g.text.astype(str)]
        flat = [w.strip(".,!?'-") for ts in toks for w in ts]
        n = max(len(flat), 1)
        lens = np.array([len(t) for t in toks])
        rows.append({
            "session_id": sid,
            "ling_n_utt": len(toks), "ling_total_words": n,
            "ling_words_per_utt": lens.mean(), "ling_words_std": lens.std(),
            "ling_fps_rate": sum(w in FPS for w in flat) / n,
            "ling_fpp_rate": sum(w in FPP for w in flat) / n,
            "ling_absolutist_rate": sum(w in ABSOLUTIST for w in flat) / n,
            "ling_negation_rate": sum(w in NEGATION for w in flat) / n,
            "ling_negaff_rate": sum(w in NEG_AFF for w in flat) / n,
            "ling_posaff_rate": sum(w in POS_AFF for w in flat) / n,
            "ling_type_token": len(set(flat)) / n,
        })
    return pd.DataFrame(rows)

def build_features(utt, tag, fake=False):
    f = (emotion_features(utt, tag, fake)
         .merge(embedding_features(utt, tag, fake), on="session_id")
         .merge(linguistic_features(utt), on="session_id"))
    llm_path = os.path.join(CACHE, "llm_phq_features.csv")
    if os.path.exists(llm_path):
        llm = pd.read_csv(llm_path)
        llm = llm[["session_id"] + [c for c in llm.columns if c.startswith("llm_")
                                    and pd.api.types.is_numeric_dtype(llm[c])]]
        f = f.merge(llm, on="session_id", how="left")
    return f

# ─────────────────────────────────────────────────────────────────────────────
# 3. MODELS (every preprocessing step is inside the pipeline -> no leakage)
# ─────────────────────────────────────────────────────────────────────────────
from sklearn.compose import ColumnTransformer
from sklearn.decomposition import PCA
from sklearn.ensemble import (RandomForestClassifier, HistGradientBoostingClassifier,
                              VotingClassifier, RandomForestRegressor)
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import (f1_score, accuracy_score, balanced_accuracy_score, roc_auc_score,
                             precision_score, recall_score, confusion_matrix,
                             mean_absolute_error, mean_squared_error)
from sklearn.model_selection import (RepeatedStratifiedKFold, StratifiedKFold, KFold,
                                     RepeatedKFold, cross_validate, cross_val_predict,
                                     permutation_test_score)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC, SVR
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline

BLOCK_PREFIX = {"EMO": "emo_", "EMB": "emb_", "LING": "ling_", "AU": "au_", "LLM": "llm_"}

def preprocessor(cols, pca_dim=32):
    emb = [c for c in cols if c.startswith("emb_")]
    rest = [c for c in cols if not c.startswith("emb_")]
    parts = []
    if emb:
        parts.append(("emb", Pipeline([("imp", SimpleImputer()), ("sc", StandardScaler()),
                                       ("pca", PCA(n_components=min(pca_dim, len(emb)),
                                                   random_state=SEED))]), emb))
    if rest:
        parts.append(("rest", Pipeline([("imp", SimpleImputer()), ("sc", StandardScaler())]), rest))
    return ColumnTransformer(parts)

def classifiers():
    lr = LogisticRegression(C=0.1, class_weight="balanced", max_iter=5000, random_state=SEED)
    svm = SVC(C=1.0, kernel="rbf", class_weight="balanced", probability=True, random_state=SEED)
    rf = RandomForestClassifier(n_estimators=500, min_samples_leaf=2, max_features="sqrt",
                                class_weight="balanced_subsample", n_jobs=-1, random_state=SEED)
    hgb = HistGradientBoostingClassifier(max_depth=3, learning_rate=0.05, max_iter=200,
                                         l2_regularization=1.0, class_weight="balanced",
                                         random_state=SEED)
    return {
        "LR": (lr, False),
        "LR+SMOTE": (LogisticRegression(C=0.1, max_iter=5000, random_state=SEED), True),
        "SVM-RBF": (svm, False),
        "RF": (rf, False),
        "HistGB": (hgb, False),
        "SoftVote(LR,SVM,RF)": (VotingClassifier([("lr", lr), ("svm", svm), ("rf", rf)],
                                                 voting="soft"), False),
    }

def make_model(cols, clf, smote):
    if smote:
        return ImbPipeline([("pre", preprocessor(cols)),
                            ("smote", SMOTE(random_state=SEED, k_neighbors=5)),
                            ("clf", clf)])
    return Pipeline([("pre", preprocessor(cols)), ("clf", clf)])

def feature_sets(columns, has_au):
    blocks = [b for b, p in BLOCK_PREFIX.items() if any(c.startswith(p) for c in columns)]
    if not has_au and "AU" in blocks:
        blocks.remove("AU")
    combos = [["EMO"], ["EMB"], ["LING"], ["EMO", "LING"], ["EMB", "LING"],
              ["EMB", "EMO"], ["EMB", "EMO", "LING"]]
    if "AU" in blocks:
        combos += [["AU"], ["EMO", "AU"], ["EMB", "EMO", "LING", "AU"]]
    if "LLM" in blocks:
        combos += [["LLM"], ["LLM", "LING"], ["LLM", "EMB"], ["LLM", "EMB", "EMO", "LING"]]
    out = {}
    for c in combos:
        if all(b in blocks for b in c):
            cols = [col for col in columns
                    if any(col.startswith(BLOCK_PREFIX[b]) for b in c)]
            out["+".join(c)] = cols
    return out

def tune_threshold(y, p):
    best_t, best_f = 0.5, -1
    for t in np.linspace(0.2, 0.8, 61):
        f = f1_score(y, (p >= t).astype(int), zero_division=0)
        if f > best_f:
            best_t, best_f = t, f
    return best_t

def metrics(y, p, t):
    yhat = (p >= t).astype(int)
    return {"f1": f1_score(y, yhat, zero_division=0), "accuracy": accuracy_score(y, yhat),
            "balanced_accuracy": balanced_accuracy_score(y, yhat),
            "precision": precision_score(y, yhat, zero_division=0),
            "recall": recall_score(y, yhat, zero_division=0),
            "roc_auc": roc_auc_score(y, p) if len(set(y)) > 1 else float("nan"),
            "threshold": t, "confusion_matrix": confusion_matrix(y, yhat).tolist(),
            "n": int(len(y)), "n_depressed": int(np.sum(y)),
            "majority_baseline_acc": float(max(np.mean(y), 1 - np.mean(y)))}

def bootstrap_ci(y, p, t, n=2000):
    rng = np.random.default_rng(SEED)
    fs = []
    for _ in range(n):
        i = rng.integers(0, len(y), len(y))
        if len(set(y[i])) < 2:
            continue
        fs.append(f1_score(y[i], (p[i] >= t).astype(int), zero_division=0))
    return [float(np.percentile(fs, 2.5)), float(np.percentile(fs, 97.5))]

def fit_eval_holdout(model, Xtr, ytr, Xte, yte):
    """Threshold from out-of-fold train predictions only, then a single test evaluation."""
    oof = cross_val_predict(model, Xtr, ytr, method="predict_proba",
                            cv=StratifiedKFold(5, shuffle=True, random_state=SEED))[:, 1]
    t = tune_threshold(ytr, oof)
    model.fit(Xtr, ytr)
    p = model.predict_proba(Xte)[:, 1]
    m = metrics(yte, p, t)
    m["f1_at_0.5"] = f1_score(yte, (p >= 0.5).astype(int), zero_division=0)
    m["f1_95ci"] = bootstrap_ci(yte, p, t)
    return m, p

# ─────────────────────────────────────────────────────────────────────────────
# 4. MAIN
# ─────────────────────────────────────────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fake", action="store_true", help="synthetic data smoke test")
    ap.add_argument("--perms", type=int, default=200)
    args = ap.parse_args()

    utt_tr, utt_te, lab_tr, lab_te, au = load_data(args.fake)
    print(f"Train+dev: {lab_tr.session_id.nunique()} sessions, {len(utt_tr)} utterances | "
          f"Test: {lab_te.session_id.nunique()} sessions, {len(utt_te)} utterances")

    F_tr = build_features(utt_tr, "traindev", args.fake).merge(lab_tr, on="session_id")
    au_cols = [c for c in au.columns if c.endswith("_mean") or c.endswith("_std")]
    au_ren = au[["session_id"] + au_cols].rename(columns={c: "au_" + c for c in au_cols})
    F_tr = F_tr.merge(au_ren, on="session_id", how="left")
    has_te = len(utt_te) > 0 and len(lab_te) > 0
    F_te = (build_features(utt_te, "test", args.fake).merge(lab_te, on="session_id")
            if has_te else None)

    y = F_tr.PHQ8_Binary.astype(int).values
    feat_cols = [c for c in F_tr.columns if any(c.startswith(p) for p in BLOCK_PREFIX.values())]
    fsets = feature_sets(feat_cols, has_au=bool(au_cols))
    print(f"Sessions {len(y)} (depressed {y.sum()}); feature sets: {list(fsets)}")

    # ---- 4a. CV grid ------------------------------------------------------------
    cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=5, random_state=SEED)
    scoring = {"f1": "f1", "bacc": "balanced_accuracy", "auc": "roc_auc",
               "acc": "accuracy", "prec": "precision", "rec": "recall"}
    rows = []
    for fs_name, cols in fsets.items():
        for clf_name, (clf, smote) in classifiers().items():
            model = make_model(cols, clf, smote)
            r = cross_validate(model, F_tr[cols], y, cv=cv, scoring=scoring, n_jobs=-1)
            row = {"features": fs_name, "model": clf_name, "n_feat": len(cols)}
            for k in scoring:
                row[f"cv_{k}_mean"] = round(r[f"test_{k}"].mean(), 4)
                row[f"cv_{k}_std"] = round(r[f"test_{k}"].std(), 4)
            rows.append(row)
            print(f"  {fs_name:28s} {clf_name:20s} F1 {row['cv_f1_mean']:.3f}±{row['cv_f1_std']:.3f}"
                  f"  bAcc {row['cv_bacc_mean']:.3f}  AUC {row['cv_auc_mean']:.3f}")
    grid = pd.DataFrame(rows).sort_values("cv_f1_mean", ascending=False)
    grid.to_csv(os.path.join(RES, "experiments_classification.csv"), index=False)

    best = grid.iloc[0]
    # Test evaluation uses the best configuration without the AU block. In the thesis run the overall best
    # configuration (sentence embeddings + LR) contains no AU features, so this choice does not change the result.
    test_ok = grid[~grid.features.str.contains("AU")]
    best_txt = test_ok.iloc[0] if len(test_ok) else None
    summary = {"majority_baseline_acc_cv": float(max(y.mean(), 1 - y.mean())),
               "previous_corrected_v9": {"f1": 0.4754, "f1_std": 0.1297, "acc": 0.7118},
               "best_cv_config": best.to_dict(),
               "best_cv_config_without_AU": None if best_txt is None else best_txt.to_dict(),
               "note": ("Best config chosen by CV F1 on train+dev only. Dev and test numbers "
                        "below are single evaluations of that pre-chosen config.")}

    # ---- 4b. permutation test on the best config ---------------------------------
    sel = best_txt if best_txt is not None else best
    cols = fsets[sel.features]
    clf, smote = classifiers()[sel.model]
    model = make_model(cols, clf, smote)
    print(f"\nPermutation test ({args.perms} perms) for {sel.features} / {sel.model} ...")
    score, perm_scores, pval = permutation_test_score(
        model, F_tr[cols], y, scoring="f1", n_permutations=args.perms, n_jobs=-1,
        cv=StratifiedKFold(5, shuffle=True, random_state=SEED), random_state=SEED)
    summary["permutation_test"] = {"config": f"{sel.features} / {sel.model}",
                                   "f1": float(score), "chance_f1_mean": float(perm_scores.mean()),
                                   "p_value": float(pval)}

    # ---- 4c. official dev split (train -> dev) -----------------------------------
    is_dev = (F_tr.split == "dev").values
    if is_dev.any() and (~is_dev).any():
        m, _ = fit_eval_holdout(make_model(cols, classifiers()[sel.model][0], smote),
                                F_tr.loc[~is_dev, cols], y[~is_dev],
                                F_tr.loc[is_dev, cols], y[is_dev])
        summary["official_dev_split"] = m

    # ---- 4d. held-out official test set (train+dev -> test) ----------------------
    if F_te is not None and len(F_te):
        yte = F_te.PHQ8_Binary.astype(int).values
        m, p = fit_eval_holdout(make_model(cols, classifiers()[sel.model][0], smote),
                                F_tr[cols], y, F_te[cols], yte)
        summary["heldout_test"] = m
        _plots(yte, p, m, sel)

    # ---- 4e. PHQ-8 severity regression -------------------------------------------
    summary["regression"] = regression(F_tr, fsets)

    with open(os.path.join(RES, "final_summary.json"), "w") as f:
        json.dump(summary, f, indent=2, default=float)
    _print_summary(grid, summary)

def regression(F_tr, fsets):
    yr = F_tr.PHQ8_Score.astype(float).values
    cv = RepeatedKFold(n_splits=5, n_repeats=5, random_state=SEED)
    models = {"Ridge": Ridge(alpha=10.0),
              "SVR": SVR(C=3.0, epsilon=1.0),
              "RF": RandomForestRegressor(n_estimators=500, min_samples_leaf=3,
                                          n_jobs=-1, random_state=SEED)}
    rows = []
    for fs_name, cols in fsets.items():
        if "AU" in fs_name:
            continue
        for name, reg in models.items():
            pipe = Pipeline([("pre", preprocessor(cols)), ("reg", reg)])
            r = cross_validate(pipe, F_tr[cols], yr, cv=cv, n_jobs=-1,
                               scoring={"mae": "neg_mean_absolute_error",
                                        "rmse": "neg_root_mean_squared_error"})
            rows.append({"features": fs_name, "model": name,
                         "cv_mae": round(-r["test_mae"].mean(), 3),
                         "cv_mae_std": round(r["test_mae"].std(), 3),
                         "cv_rmse": round(-r["test_rmse"].mean(), 3)})
    reg = pd.DataFrame(rows).sort_values("cv_mae")
    reg.to_csv(os.path.join(RES, "experiments_regression.csv"), index=False)
    # predict-the-training-mean baseline, computed inside the same folds
    base = []
    for tr, te in cv.split(yr):
        base.append(mean_absolute_error(yr[te], np.full(len(te), yr[tr].mean())))
    return {"best": reg.iloc[0].to_dict(), "mean_baseline_mae": round(float(np.mean(base)), 3),
            "previous_v9_best_mae": 4.3637}

def _plots(y, p, m, sel):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from sklearn.metrics import RocCurveDisplay, ConfusionMatrixDisplay
    fig, ax = plt.subplots(1, 2, figsize=(10, 4))
    RocCurveDisplay.from_predictions(y, p, ax=ax[0], name=f"{sel.features}/{sel.model}")
    ax[0].plot([0, 1], [0, 1], "--", color="grey")
    ax[0].set_title(f"Held-out test ROC (AUC={m['roc_auc']:.3f})")
    ConfusionMatrixDisplay(np.array(m["confusion_matrix"]),
                           display_labels=["Not dep.", "Depressed"]).plot(ax=ax[1], colorbar=False)
    ax[1].set_title(f"Test confusion (F1={m['f1']:.3f})")
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "heldout_test_roc_confusion.png"), dpi=200)

def _print_summary(grid, s):
    print("\n" + "=" * 70)
    print("TOP 10 CONFIGS (5x5 repeated CV, train+dev, leakage-free)")
    print(grid.head(10)[["features", "model", "cv_f1_mean", "cv_f1_std", "cv_bacc_mean",
                         "cv_auc_mean"]].to_string(index=False))
    print(f"\nMajority baseline acc: {s['majority_baseline_acc_cv']:.3f} | "
          f"previous corrected v9 F1: 0.4754")
    pt = s["permutation_test"]
    print(f"Permutation test {pt['config']}: F1 {pt['f1']:.3f} vs chance "
          f"{pt['chance_f1_mean']:.3f}, p = {pt['p_value']:.4f}")
    for k in ("official_dev_split", "heldout_test"):
        if k in s:
            m = s[k]
            extra = f" 95% CI {m['f1_95ci'][0]:.3f}-{m['f1_95ci'][1]:.3f}"
            print(f"{k:20s}: F1 {m['f1']:.3f}{extra} | bAcc {m['balanced_accuracy']:.3f} | "
                  f"AUC {m['roc_auc']:.3f} | P {m['precision']:.3f} R {m['recall']:.3f} "
                  f"(n={m['n']})")
    r = s["regression"]
    print(f"PHQ-8 regression best: {r['best']['features']}/{r['best']['model']} "
          f"MAE {r['best']['cv_mae']:.3f} (mean baseline {r['mean_baseline_mae']:.3f}, v9 4.364)")
    print("Saved: results/experiments_classification.csv, results/experiments_regression.csv, "
          "results/final_summary.json, figures/heldout_test_roc_confusion.png")

if __name__ == "__main__":
    main()
