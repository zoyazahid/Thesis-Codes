"""Step 8 (CPU) - builds the Experiment 1 evaluation set: 128 EmpatheticDialogues TEST conversations
(4 per emotion label, seed 42) with the 6DE state of the user turn (RoBERTa-GoEmotions top-3 -> 6DE),
dominant emotion, regulation gap and top-3 RAG strategies (bge-small-en). Output: inputs/coreg_scenarios.json
(the thesis copy is shipped; the script reports whether a re-run reproduces it)."""
import json, re, numpy as np, pandas as pd
from transformers import pipeline
from sentence_transformers import SentenceTransformer

def save_input(obj, name):
    """Writes inputs/<name>; if a shipped copy exists and differs, keeps it and writes <name>.new instead."""
    import os
    path = f"inputs/{name}"; new = json.dumps(obj, indent=1)
    if os.path.exists(path) and open(path).read() != new:
        open(path + ".new", "w").write(new); print(f"NOTE: result differs from shipped {path}; written to {path}.new")
    else:
        open(path, "w").write(new); print(f"{path}: identical to the thesis input" if os.path.exists(path) else f"wrote {path}")

ed = pd.read_parquet("data/ed_test.parquet")
def split(ref):
    lines = [l for l in str(ref[0] if len(ref) else "").split("\n") if ":" in l]
    turns = [l.split(":", 1)[1].strip() for l in lines]
    return (turns[0], turns[1]) if len(turns) >= 2 else (None, None)
ed[["user", "human_reply"]] = ed.references.apply(lambda r: pd.Series(split(r)))
ed = ed.dropna(subset=["user", "human_reply"])
ed = ed[ed.user.str.split().str.len() >= 6]
sc = ed.groupby("subsplit").sample(4, random_state=42).reset_index(drop=True)
sc = sc.rename(columns={"subsplit": "ed_emotion", "input": "situation"})
print(len(sc), "scenarios,", sc.ed_emotion.nunique(), "emotion labels")

from common import TO6, TARGET, KB
emo = pipeline("text-classification", model="SamLowe/roberta-base-go_emotions", top_k=3,
               truncation=True, max_length=128, device=-1)
def six(text):
    v = {k: 0.0 for k in TARGET}
    for d in emo([text])[0]:
        if d["label"] in TO6:
            v[TO6[d["label"]]] += d["score"]
    t = sum(v.values())
    return {k: round(x / t, 4) if t > 0 else 0.0 for k, x in v.items()}
emb = SentenceTransformer("BAAI/bge-small-en", device="cpu")
kbE = emb.encode(KB, normalize_embeddings=True)
out = []
for r in sc.itertuples():
    v = six(r.user); dom = max(v, key=v.get) if sum(v.values()) else "sad"
    gap = sum(abs(v[k] - TARGET[k]) for k in TARGET)
    q = emb.encode([f"therapeutic coping strategy for person feeling {dom}"], normalize_embeddings=True)
    top = np.argsort(-(kbE @ q[0]))[:3]
    out.append({"id": len(out), "ed_emotion": r.ed_emotion, "situation": r.situation,
                "user": r.user.replace("_comma_", ","), "human_reply": r.human_reply.replace("_comma_", ","),
                "six_de": v, "dominant": dom, "gap": round(gap, 4), "rag": [KB[i] for i in top]})
save_input(out, "coreg_scenarios.json")
print(pd.Series([o["dominant"] for o in out]).value_counts().to_dict())
print(json.dumps(out[0], indent=1)[:900])
