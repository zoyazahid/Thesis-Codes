"""Step 1 - Pipeline B, Component 1 (CPU): multi-label emotion recognition on GoEmotions.
A1 TF-IDF + logistic regression, A2 TF-IDF + linear SVM, A3 pretrained RoBERTa-GoEmotions.
Per-label thresholds tuned on the validation split; all numbers on the test split.
Also validates the 6DE projection against the human GoEmotions labels (Component 2).
Outputs: results/c1_goemotions_results.csv, results/c1_per_label_f1.csv, results/c1_6de_validation.json"""
import json, os, numpy as np, pandas as pd, warnings
warnings.filterwarnings("ignore")
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.multiclass import OneVsRestClassifier
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.metrics import (f1_score, precision_score, recall_score, hamming_loss,
                             accuracy_score, confusion_matrix)
D = "data"; R = "results"; os.makedirs(R, exist_ok=True)
LABELS = ["admiration", "amusement", "anger", "annoyance", "approval", "caring", "confusion",
          "curiosity", "desire", "disappointment", "disapproval", "disgust", "embarrassment",
          "excitement", "fear", "gratitude", "grief", "joy", "love", "nervousness", "optimism",
          "pride", "realization", "relief", "remorse", "sadness", "surprise", "neutral"]
# Thesis Table 3 mapping (pipeline EMOTION_TO_6DE), restricted to GoEmotions labels
TO6 = {"sadness": "sad", "grief": "sad", "disappointment": "sad", "remorse": "sad", "embarrassment": "sad",
       "joy": "happy", "excitement": "happy", "amusement": "happy", "gratitude": "happy", "relief": "happy",
       "optimism": "happy", "pride": "happy", "admiration": "happy", "approval": "happy",
       "fear": "fear", "nervousness": "fear",
       "anger": "anger", "annoyance": "anger", "disgust": "anger", "disapproval": "anger",
       "surprise": "surprise", "realization": "surprise", "confusion": "surprise", "curiosity": "surprise",
       "love": "love", "caring": "love", "desire": "love"}
SIX = ["sad", "happy", "fear", "anger", "surprise", "love"]

sp = {s: pd.read_parquet(f"{D}/go_{s}.parquet") for s in ["train", "validation", "test"]}
mlb = MultiLabelBinarizer(classes=list(range(28)))
Y = {s: mlb.fit_transform(sp[s].labels) for s in sp}
X = {s: sp[s].text.tolist() for s in sp}
print({s: len(X[s]) for s in X})

def tune_thresholds(scores, y, grid):
    th = np.zeros(scores.shape[1])
    for j in range(scores.shape[1]):
        best = max(grid, key=lambda t: f1_score(y[:, j], scores[:, j] >= t, zero_division=0))
        th[j] = best
    return th

def report(name, yt, yp):
    return {"model": name,
            "micro_f1": f1_score(yt, yp, average="micro", zero_division=0),
            "macro_f1": f1_score(yt, yp, average="macro", zero_division=0),
            "weighted_f1": f1_score(yt, yp, average="weighted", zero_division=0),
            "micro_precision": precision_score(yt, yp, average="micro", zero_division=0),
            "micro_recall": recall_score(yt, yp, average="micro", zero_division=0),
            "macro_precision": precision_score(yt, yp, average="macro", zero_division=0),
            "macro_recall": recall_score(yt, yp, average="macro", zero_division=0),
            "hamming_loss": hamming_loss(yt, yp),
            "exact_match": accuracy_score(yt, yp)}

rows, per_label = [], {}
vec = TfidfVectorizer(ngram_range=(1, 2), min_df=2, max_features=100000, sublinear_tf=True)
Xtr = vec.fit_transform(X["train"]); Xva = vec.transform(X["validation"]); Xte = vec.transform(X["test"])
# majority / prior baseline: always predict the most frequent label (neutral)
yp = np.zeros_like(Y["test"]); yp[:, Y["train"].sum(0).argmax()] = 1
rows.append(report("Baseline: always 'neutral'", Y["test"], yp))

for name, clf, method in [
        ("A1 TF-IDF + Logistic Regression", OneVsRestClassifier(LogisticRegression(C=4, max_iter=2000), n_jobs=-1), "proba"),
        ("A2 TF-IDF + Linear SVM", OneVsRestClassifier(LinearSVC(C=0.5), n_jobs=-1), "dec")]:
    clf.fit(Xtr, Y["train"])
    f = (lambda Z: clf.predict_proba(Z)) if method == "proba" else (lambda Z: clf.decision_function(Z))
    sva, ste = f(Xva), f(Xte)
    grid = np.linspace(0.05, 0.9, 35) if method == "proba" else np.linspace(-1.0, 0.5, 31)
    th = tune_thresholds(sva, Y["validation"], grid)
    yp = (ste >= th).astype(int)
    rows.append(report(name, Y["test"], yp)); print(rows[-1], flush=True)
    per_label[name] = f1_score(Y["test"], yp, average=None, zero_division=0)

# A3 pretrained RoBERTa
cache = "data_cache/roberta_go_scores.npz"
if os.path.exists(cache):
    z = np.load(cache); rva, rte = z["va"], z["te"]
else:
    from transformers import pipeline
    pipe = pipeline("text-classification", model="SamLowe/roberta-base-go_emotions", top_k=None,
                    truncation=True, max_length=128, device=-1)
    def score(texts):
        out = pipe(texts, batch_size=32)
        return np.array([[{d["label"]: d["score"] for d in o}[l] for l in LABELS] for o in out])
    rva, rte = score(X["validation"]), score(X["test"])
    np.savez(cache, va=rva, te=rte)
yp = (rte >= 0.5).astype(int)
rows.append(report("A3 RoBERTa-GoEmotions (threshold 0.5)", Y["test"], yp)); print(rows[-1])
th = tune_thresholds(rva, Y["validation"], np.linspace(0.05, 0.9, 35))
yp = (rte >= th).astype(int)
rows.append(report("A3 RoBERTa-GoEmotions (val-tuned thresholds)", Y["test"], yp)); print(rows[-1])
per_label["A3 RoBERTa-GoEmotions (val-tuned thresholds)"] = f1_score(Y["test"], yp, average=None, zero_division=0)

res = pd.DataFrame(rows); res.to_csv(f"{R}/c1_goemotions_results.csv", index=False)
pl = pd.DataFrame(per_label, index=LABELS); pl["support"] = Y["test"].sum(0); pl.to_csv(f"{R}/c1_per_label_f1.csv")

# ---- 6DE projection validated against human labels -----------------------------------------
gold6, keep = [], []
for i, labs in enumerate(sp["test"].labels):
    cats = {TO6[LABELS[l]] for l in labs if LABELS[l] in TO6}
    gold6.append(cats); keep.append(len(cats) > 0)
keep = np.array(keep)
def proj(scores, topk=None):
    vec6 = np.zeros((len(scores), 6))
    for i, s in enumerate(scores):
        idx = np.argsort(-s)[:topk] if topk else range(28)
        for j in idx:
            if LABELS[j] in TO6:
                vec6[i, SIX.index(TO6[LABELS[j]])] += s[j]
    return vec6
out6 = {}
for nm, k in [("thesis method (top-3 labels)", 3), ("all 28 probabilities", None)]:
    v = proj(rte, k); pred = v.argmax(1)
    hit = np.mean([SIX[p] in g for p, g in zip(pred[keep], np.array(gold6, dtype=object)[keep])])
    single = np.array([len(g) == 1 for g in gold6]) & keep
    gs = [SIX.index(next(iter(g))) for g in np.array(gold6, dtype=object)[single]]
    out6[nm] = {"n_samples_with_6DE_gold": int(keep.sum()), "hit_rate_dominant_in_gold": hit,
                "n_single_category": int(single.sum()),
                "accuracy_single": accuracy_score(gs, pred[single]),
                "macro_f1_single": f1_score(gs, pred[single], average="macro"),
                "confusion_single": confusion_matrix(gs, pred[single], labels=range(6)).tolist()}
out6["excluded_neutral_only_share"] = float(1 - keep.mean())
json.dump(out6, open(f"{R}/c1_6de_validation.json", "w"), indent=2, default=float)
print(res.round(4).to_string(index=False)); print(json.dumps({k: (v if not isinstance(v, dict) else
      {a: b for a, b in v.items() if a != "confusion_single"}) for k, v in out6.items()}, indent=1, default=float))
