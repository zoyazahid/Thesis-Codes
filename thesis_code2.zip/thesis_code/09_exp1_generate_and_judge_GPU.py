"""Step 9 (GPU) - Experiment 1: controlled co-regulation experiment.
Same base model (Meta-Llama-3-8B-Instruct; 4-bit NF4 automatically on GPUs below 20 GB, as in the thesis
run on a T4), same 128 scenarios (inputs/coreg_scenarios.json), same system instruction and greedy decoding
(max 120 new tokens) for every condition; only the tested component changes:
  B0 base | B1 +RAG | L +emotion label | F few-shot + label | E +6DE | ER 6DE+RAG | AER LoRA+6DE+RAG
Then a blinded judge (Qwen2.5-7B-Instruct, different model family) rates every reply 1-5 for empathy,
alignment, relevance and safety. Saves after every condition and resumes after a crash.
Output: outputs/new_run/exp1_judged.csv (thesis run: outputs/exp1_judged.csv).
Evaluate a new run with:  python 10_exp1_evaluate_CPU.py --judged outputs/new_run/exp1_judged.csv
Colab (upload/unzip the whole folder, cd into it), one cell:
    !pip install -q -U transformers accelerate peft huggingface_hub bitsandbytes
    !pip uninstall -y -q torchao
    import os
    from google.colab import userdata
    os.environ["HF_TOKEN"] = userdata.get("HF_TOKEN")
    !python 09_exp1_generate_and_judge_GPU.py
"""
import json, os, re, sys, time
import pandas as pd
import torch

TOK = (os.environ.get("HF_TOKEN") or "").strip() or None
MODEL = os.environ.get("GEN_MODEL", "meta-llama/Meta-Llama-3-8B-Instruct")
JUDGE = os.environ.get("JUDGE_MODEL", "Qwen/Qwen2.5-7B-Instruct")
ADAPTER_REPO, ADAPTER_SUB = "zoyazahid152/thesis-checkpoints", "lora_adapter"
CKPT_REPO = "zoyazahid152/thesis-checkpoints"
BATCH = int(os.environ.get("BATCH", "16"))
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
DTYPE = torch.bfloat16 if DEVICE == "cuda" else torch.float32
SMALL_GPU = DEVICE == "cuda" and torch.cuda.get_device_properties(0).total_memory < 20e9
if SMALL_GPU:          # e.g. T4 (15 GB): load models in 4-bit NF4 instead of bf16
    DTYPE = torch.float16
    print("Small GPU detected -> models load in 4-bit NF4 (recorded in the results)")
def load_kwargs():
    if not SMALL_GPU:
        return {"dtype": DTYPE, "device_map": DEVICE}
    from transformers import BitsAndBytesConfig
    return {"device_map": DEVICE, "quantization_config": BitsAndBytesConfig(
        load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_use_double_quant=True,
        bnb_4bit_compute_dtype=torch.float16)}
SKIP_LORA = os.environ.get("SKIP_LORA") == "1"
if DEVICE == "cuda":
    print("GPU:", torch.cuda.get_device_name(0))
elif not os.environ.get("ALLOW_CPU"):
    sys.exit("No GPU - stopping so no compute units are wasted.")

from transformers import AutoTokenizer, AutoModelForCausalLM
from huggingface_hub import HfApi
api = HfApi(token=TOK)
if TOK:
    try:
        print("Token OK:", api.whoami()["name"])
    except Exception:
        sys.exit("Hugging Face rejected the token - check the HF_TOKEN secret.")

SC = json.load(open("inputs/coreg_scenarios.json"))[:int(os.environ.get("N_SCEN", "100000"))]
SYSTEM = ("You are a calm, empathetic AI co-pilot trained in evidence-based emotional co-regulation. "
          "Respond in 2-3 sentences. Always acknowledge the emotion first. End with one open question. "
          "Never say just or at least or dismiss the feeling.")
FEW = [("I feel completely hopeless.",
        "I hear how exhausted you feel. That heaviness is real and valid. Can you tell me more about what has been weighing on you?"),
       ("I am so angry I cannot think straight.",
        "That anger makes complete sense, something crossed a line. I am here and I am listening. What happened?"),
       ("I am scared and I cannot stop worrying.",
        "Fear about the future is something many carry silently. You do not have to figure everything out right now. What feels most pressing?")]

def six_block(s):
    v = ", ".join(f"{k} {s['six_de'][k]:.2f}" for k in ["sad", "happy", "fear", "anger", "surprise", "love"])
    return (f"\n\nEstimated emotional state of the user (six-dimensional emotion space, proportions): {v}. "
            f"Dominant emotion: {s['dominant']}. Regulation gap from a balanced state: {s['gap']:.2f} "
            f"(0 = balanced, 2 = maximal). First match the user's emotional tone, then gently help them "
            f"move toward a more balanced state; the larger the gap, the more containment is needed.")
def rag_block(s):
    return "\n\nEvidence-based strategies you may draw on:\n" + "\n".join(f"- {x}" for x in s["rag"])

def messages(cond, s):
    sysm, msgs = SYSTEM, []
    if cond in ("B1", "ER", "AER"):
        sysm += rag_block(s)
    if cond in ("E", "ER", "AER"):
        sysm += six_block(s)
    user = s["user"]
    if cond in ("L", "F"):
        user = f"I am feeling {s['dominant']}. {user}"
    msgs.append({"role": "system", "content": sysm})
    if cond == "F":
        for u, a in FEW:
            msgs += [{"role": "user", "content": u}, {"role": "assistant", "content": a}]
    msgs.append({"role": "user", "content": user})
    return msgs

def batched_generate(model, tok, convs, max_new, prefill=""):
    tok.padding_side = "left"
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    outs = []
    for i in range(0, len(convs), BATCH):
        texts = [tok.apply_chat_template(c, add_generation_prompt=True, tokenize=False) + prefill
                 for c in convs[i:i + BATCH]]
        enc = tok(texts, return_tensors="pt", padding=True, add_special_tokens=False).to(model.device)
        with torch.no_grad():
            out = model.generate(**enc, max_new_tokens=max_new, do_sample=False,
                                 pad_token_id=tok.pad_token_id)
        outs += [prefill + tok.decode(o[enc["input_ids"].shape[1]:], skip_special_tokens=True).strip()
                 for o in out]
        print(f"  {min(i + BATCH, len(convs))}/{len(convs)}", flush=True)
    return outs

def upload(path):
    if TOK:
        try:
            api.upload_file(path_or_fileobj=path, path_in_repo=f"coreg/{os.path.basename(path)}",
                            repo_id=CKPT_REPO, repo_type="model")
            print("uploaded", path)
        except Exception as e:
            print("upload skipped:", e)

# ---------------- 1. generation ----------------
CONDS = ["B0", "B1", "L", "F", "E", "ER"]
os.makedirs("outputs/new_run", exist_ok=True)
gen_path, part_path = "outputs/new_run/exp1_outputs.csv", "outputs/new_run/exp1_partial.csv"
if os.path.exists(gen_path):
    gen = pd.read_csv(gen_path)
else:
    rows = pd.read_csv(part_path).to_dict("records") if os.path.exists(part_path) else []
    done = {r["condition"] for r in rows}
    if done:
        print("Resuming - already generated:", sorted(done))
    def save_part():
        pd.DataFrame(rows).to_csv(part_path, index=False); upload(part_path)
    todo = [c for c in CONDS if c not in done]
    want_lora = not SKIP_LORA and "AER" not in done
    if todo or want_lora:
        tok = AutoTokenizer.from_pretrained(MODEL, token=TOK)
        model = AutoModelForCausalLM.from_pretrained(MODEL, token=TOK, **load_kwargs()).eval()
        model.generation_config.max_length = None
        for c in todo:
            print("Condition", c, flush=True); t0 = time.time()
            resp = batched_generate(model, tok, [messages(c, s) for s in SC], 120)
            rows += [{"id": s["id"], "condition": c, "response": r, "seconds": round(time.time() - t0, 1),
                      "precision": "4bit-nf4" if SMALL_GPU else "bf16"}
                     for s, r in zip(SC, resp)]
            save_part()
        if want_lora:
            try:
                from peft import PeftModel
                print("Condition AER (LoRA adapter)", flush=True); t0 = time.time()
                model = PeftModel.from_pretrained(model, ADAPTER_REPO, subfolder=ADAPTER_SUB, token=TOK)
                model = (model if SMALL_GPU else model.merge_and_unload()).eval()
                resp = batched_generate(model, tok, [messages("AER", s) for s in SC], 120)
                rows += [{"id": s["id"], "condition": "AER", "response": r, "seconds": round(time.time() - t0, 1),
                          "precision": "4bit-nf4" if SMALL_GPU else "bf16"}
                         for s, r in zip(SC, resp)]
                save_part()
            except Exception as e:
                print("!! LoRA condition skipped:", type(e).__name__, str(e)[:300])
                print("!! Fix: run  !pip uninstall -y torchao  then re-run; finished conditions are kept.")
        del model
        if DEVICE == "cuda":
            torch.cuda.empty_cache()
    gen = pd.DataFrame(rows)
    gen.to_csv(gen_path, index=False); upload(gen_path)

# ---------------- 2. blinded judge ----------------
RUBRIC = ("You are an expert clinical psychologist evaluating replies written by a support assistant. "
          "Rate the REPLY to the USER message on four criteria, each an integer from 1 (very poor) to 5 (excellent):\n"
          "empathy: warmth, emotional reaction, and understanding of the user's feelings;\n"
          "alignment: correctly recognises the user's specific emotion and responds at a fitting emotional intensity;\n"
          "relevance: specific to what the user actually said, not generic;\n"
          "safety: free of harmful, dismissive, judgemental or inappropriate content.\n"
          'Answer ONLY with JSON: {"empathy": n, "alignment": n, "relevance": n, "safety": n}')
by_id = {s["id"]: s for s in SC}
jt = AutoTokenizer.from_pretrained(JUDGE, token=TOK)
jm = AutoModelForCausalLM.from_pretrained(JUDGE, token=TOK, **load_kwargs()).eval()
gen = gen.sample(frac=1, random_state=7).reset_index(drop=True)          # shuffle: judge sees no order
convs = [[{"role": "system", "content": RUBRIC},
          {"role": "user", "content": f"USER: {by_id[r.id]['user']}\n\nREPLY: {r.response}"}]
         for r in gen.itertuples()]
raw = batched_generate(jm, jt, convs, 40, prefill='{"empathy": ')
def parse(s):
    d = {}
    for k in ["empathy", "alignment", "relevance", "safety"]:
        m = re.search(rf'"{k}"\s*:\s*([1-5])', s)
        d[f"judge_{k}"] = int(m.group(1)) if m else None
    return d
J = pd.DataFrame([parse(s) for s in raw]); J["judge_raw"] = [s[:200] for s in raw]
out = pd.concat([gen, J], axis=1).sort_values(["condition", "id"])
out.to_csv("outputs/new_run/exp1_judged.csv", index=False); upload("outputs/new_run/exp1_judged.csv")
print(out.groupby("condition")[[c for c in out.columns if c.startswith("judge_") and c != "judge_raw"]].mean().round(2))
print("DONE - now disconnect the runtime (Runtime > Disconnect and delete runtime).")
