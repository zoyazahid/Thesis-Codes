"""Shared settings for the thesis code (Human-AI Co-Regulation: Shared Emotional State Balancing
with LLM Co-Pilots). Run every script from the folder that contains this file."""
import os

SEED = 42
HF_DATA_REPO = "zoyazahid152/diacwoz-dataset"          # DAIC-WOZ (private, licensed)
HF_CKPT_REPO = "zoyazahid152/thesis-checkpoints"       # cleaned transcripts, AU features, adapters
DATA, CACHE, INPUTS, OUTPUTS, RESULTS, FIGURES = "data", "data_cache", "inputs", "outputs", "results", "figures"
for _d in (DATA, CACHE, INPUTS, OUTPUTS, RESULTS, FIGURES):
    os.makedirs(_d, exist_ok=True)

def hf_token():
    """HF token from the environment (VS Code / terminal) or from Colab secrets."""
    t = os.environ.get("HF_TOKEN")
    if t:
        return t.strip()
    try:
        from google.colab import userdata
        return userdata.get("HF_TOKEN").strip()
    except Exception:
        return None

# GoEmotions label -> six-dimensional emotion space (6DE), thesis Table "6DE mapping"
TO6 = {"sadness": "sad", "grief": "sad", "disappointment": "sad", "remorse": "sad", "embarrassment": "sad",
       "joy": "happy", "excitement": "happy", "amusement": "happy", "gratitude": "happy", "relief": "happy",
       "optimism": "happy", "pride": "happy", "admiration": "happy", "approval": "happy",
       "fear": "fear", "nervousness": "fear",
       "anger": "anger", "annoyance": "anger", "disgust": "anger", "disapproval": "anger",
       "surprise": "surprise", "realization": "surprise", "confusion": "surprise", "curiosity": "surprise",
       "love": "love", "caring": "love", "desire": "love"}
SIX = ["sad", "happy", "fear", "anger", "surprise", "love"]
TARGET = {"sad": 0.1, "happy": 0.6, "fear": 0.05, "anger": 0.05, "surprise": 0.1, "love": 0.1}

# RAG knowledge base (20 evidence-based strategies, identical in Pipeline A and Pipeline B)
KB = [
 "For sadness, validate feelings first. Reflect back: I hear how heavy this feels right now.",
 "Behavioral activation helps depression: encourage small, manageable enjoyable activities.",
 "Grief needs acknowledgment, not solutions. Avoid toxic positivity and minimizing.",
 "Box breathing reduces anxiety: inhale 4s, hold 4s, exhale 4s, hold 4s.",
 "Grounding 5-4-3-2-1: 5 things you see, 4 touch, 3 hear, 2 smell, 1 taste.",
 "Cognitive reframing: gently help identify and question catastrophic thinking patterns.",
 "For anger, validate the underlying hurt before problem-solving. Anger often masks fear.",
 "Progressive muscle relaxation: tense and release muscle groups to reduce arousal.",
 "STOP technique: Stop, Take a breath, Observe your thoughts, Proceed mindfully.",
 "Mindfulness: encourage noticing the present moment without judgment or self-criticism.",
 "Active listening: reflect feelings back without judgment, advice, or premature solutions.",
 "Empathic validation: I can understand why you would feel that way given what happened.",
 "Self-compassion: encourage treating oneself as kindly as one would treat a good friend.",
 "Social support is a key protective factor against depression and anxiety.",
 "Co-regulation: the AI models calm, present-moment awareness to help the user regulate.",
 "Pacing technique: match the user's emotional tone first, then gradually shift toward calm.",
 "Avoid minimizing responses: never say just calm down or it could be worse.",
 "Psychoeducation: explaining the neuroscience of emotions reduces shame and normalizes them.",
 "Validation: It makes complete sense you feel this way given what happened.",
 "Containment: help the user identify one small manageable next step rather than everything."]
