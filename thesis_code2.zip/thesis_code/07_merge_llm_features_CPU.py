"""Step 7 (CPU) - merge the two LLaMA-3 PHQ-8 passes into data_cache/llm_phq_features.csv.
First-pass rows are kept for the sessions that parsed completely; the 77 re-scored sessions replace
the rest. Adds llm_total (sum of items, needs at least 7 items) and llm_mean_item.
Defaults are the thesis outputs; pass --first / --rescored to use files from a new run."""
import argparse, pandas as pd
from scipy.stats import spearmanr
ap = argparse.ArgumentParser()
ap.add_argument("--first", default="outputs/llm_phq_raw_first_pass.csv")
ap.add_argument("--rescored", default="outputs/llm_phq_raw_rescored.csv")
args = ap.parse_args()
I = [f"llm_item{i}" for i in range(1, 9)]
a = pd.read_csv(args.first); b = pd.read_csv(args.rescored)
a = a[~a.session_id.isin(b.session_id)]
m = pd.concat([a, b])[["session_id"] + I].sort_values("session_id")
m["llm_total"] = m[I].sum(axis=1, min_count=7)
m["llm_mean_item"] = m[I].mean(axis=1)
m.to_csv("data_cache/llm_phq_features.csv", index=False)
print(len(m), "sessions; rows with a missing item:", int(m[I].isna().any(axis=1).sum()))
try:
    lab = pd.read_csv("data/clean_transcripts.csv").groupby("session_id")[["PHQ8_Score", "PHQ8_Binary"]].first().dropna()
    x = m.merge(lab, left_on="session_id", right_index=True)
    print("Spearman llm_total vs PHQ-8:", round(spearmanr(x.llm_total, x.PHQ8_Score, nan_policy="omit")[0], 3), "n =", len(x))
except FileNotFoundError:
    print("(run 00_download_data_CPU.py to also print the correlation with PHQ-8)")
