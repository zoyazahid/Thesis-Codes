# Expected results

Each CPU step prints and saves these values (they are the numbers reported in the thesis).

## Step 1 - emotion recognition (results/c1_goemotions_results.csv)

| Model | Micro-F1 | Macro-F1 |
|---|---|---|
| Baseline: always 'neutral' | 0.3040 | 0.0177 |
| A1 TF-IDF + Logistic Regression | 0.5327 | 0.4422 |
| A2 TF-IDF + Linear SVM | 0.5362 | 0.4571 |
| A3 RoBERTa-GoEmotions (threshold 0.5) | 0.5855 | 0.4503 |
| A3 RoBERTa-GoEmotions (val-tuned thresholds) | 0.6023 | 0.5228 |

6DE vs human labels (results/c1_6de_validation.json): accuracy 0.7947, macro-F1 0.7493, hit rate 0.8048

## Step 2 - depression detection (results/final_summary.json)

- Best CV configuration: EMB / LR, CV F1 0.5761 ± 0.1233
- Held-out test: F1 0.5714 (95% CI 0.375-0.735), AUC 0.8009, recall 0.8571, balanced accuracy 0.6861
- Official dev split: F1 0.5556, AUC 0.7210
- Permutation test: F1 0.5208, p = 0.0050
- PHQ-8 regression best: EMB/Ridge MAE 3.906 (mean baseline 4.779)

## Step 3 - baselines (results/daic_tfidf_baselines.json)

- TF-IDF + LR: CV F1 0.0436, test F1 0.5200, test AUC 0.6948

## Step 4 - nested CV (results/nested_tuning.csv)

- Nested F1 range 0.5163-0.5600

## Step 10 - Experiment 1 (results/exp1/c3_summary.csv)

| Condition | Empathy | Alignment | Relevance | Safety | BERTScore |
|---|---|---|---|---|---|
| B0 | 4.133 | 4.188 | 4.570 | 5.000 | 0.1663 |
| B1 | 4.094 | 4.125 | 4.680 | 4.992 | 0.1673 |
| L | 4.125 | 4.102 | 4.320 | 4.945 | 0.1606 |
| F | 3.992 | 3.977 | 4.281 | 4.938 | 0.2018 |
| E | 4.094 | 3.992 | 4.234 | 4.953 | 0.1655 |
| ER | 4.125 | 4.055 | 4.430 | 4.969 | 0.1645 |
| AER | 3.953 | 3.844 | 4.211 | 4.945 | 0.1935 |

## Step 13 - Experiment 2 (results/exp2/c3_summary.csv)

| Condition | Composite | Relevance | BERTScore |
|---|---|---|---|
| B0 | 4.284 | 4.625 | 0.1739 |
| B1 | 4.320 | 4.609 | 0.1718 |
| E | 4.174 | 4.297 | 0.1651 |
| ER | 4.174 | 4.281 | 0.1715 |
| E2 | 4.289 | 4.586 | 0.1855 |
| E2R | 4.297 | 4.586 | 0.1785 |
| AER | 4.115 | 4.375 | 0.1944 |
| NER | 2.776 | 3.344 | 0.3153 |
| N2R | 2.737 | 3.383 | 0.3166 |

Pre-registered tests, composite (results/exp2/c3_tests.csv, metric judge_mean):

- B0 -> E2: Δ +0.0052, Holm p = 1.0000
- B1 -> E2R: Δ -0.0234, Holm p = 0.9918
- E -> E2: Δ +0.1146, Holm p = 0.9918
- B0 -> E: Δ -0.1094, Holm p = 1.0000
- AER -> NER: Δ -1.3385, Holm p = 0.0000
- E2R -> N2R: Δ -1.5599, Holm p = 0.0000

## Pipeline A (original pipeline, from its run logs; not re-run by this package)

- Reported (SMOTE before CV): F1 0.8206 ± 0.0579; ablation 0.7881 / 0.7599 / 0.8242
- Same pipeline with SMOTE inside the folds: F1 0.4754 ± 0.1297; ablation 0.5464 / 0.1957 / 0.3739
- Fine-tuning: 4-bit 8.12 GB / 1 h 20 min; 8-bit 11.64 GB / 3 h 11 min; bf16 16.38 GB / 37 min; mean test BERTScore 0.7752 / 0.7735 / 0.7729
