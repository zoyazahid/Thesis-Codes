"""Step 2 - Pipeline B depression detection (CPU). Writes results/experiments_classification.csv,
results/experiments_regression.csv, results/final_summary.json, figures/heldout_test_roc_confusion.png.
For the exact thesis numbers run 07_merge_llm_features_CPU.py first (adds the LLaMA PHQ-8 block)."""
import sys, depression
if __name__ == "__main__":
    sys.argv = sys.argv[:1] + sys.argv[1:]
    depression.main()
