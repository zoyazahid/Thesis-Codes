"""Step 11 (CPU) - Experiment 2 inputs, fixed before any Experiment 2 generation (pre-registered):
 (1) inputs/exp2_scenarios.json - 128 FRESH EmpatheticDialogues test conversations (4 per emotion, seed 2026),
     disjoint from Experiment 1, with the 6DE state, the full GoEmotions distribution, RAG strategies and the
     redesigned, confidence-gated state description (E2).
 (2) inputs/exp2_lora_train.jsonl / exp2_lora_val.jsonl - LoRA data from the ED train / validation splits
     (speaker opening -> human listener reply of 8-60 words containing a question).
The shipped copies are the pre-registered files; their hashes are listed in inputs/exp2_preregistration.md."""
import json, random, numpy as np, pandas as pd
from transformers import pipeline
from sentence_transformers import SentenceTransformer

def save_input(obj, name):
    """Writes inputs/<name>; if a shipped copy exists and differs, keeps it and writes <name>.new instead."""
    import os
    path = f"inputs/{name}"; new = json.dumps(obj, indent=1)
    if os.path.exists(path) and open(path).read() != new:
        open(path + ".new", "w").write(new); print(f"NOTE: result differs from shipped {path}; written to {path}.new")
    else:
        open(path, "w").write(new); print(f"{path}: identical to the thesis input" if os.path.exists(path) else f"wrote {path}")

def turns(ref):
    lines = [l for l in str(ref[0] if len(ref) else "").split("\n") if ":" in l]
    t = [l.split(":", 1)[1].strip().replace("_comma_", ",") for l in lines]
    return (t[0], t[1]) if len(t) >= 2 else (None, None)
def load(path):
    d = pd.read_parquet(path)
    d[["user", "reply"]] = d.references.apply(lambda r: pd.Series(turns(r)))
    return d.dropna(subset=["user", "reply"])

# ---------------- (1) fresh scenarios
te = load("data/ed_test.parquet")
used = json.load(open("inputs/coreg_scenarios.json"))
used_keys = {(s["situation"], s["user"]) for s in used}
te = te[~te.apply(lambda r: (r.input, r.user) in used_keys, axis=1)]
te = te[te.user.str.split().str.len() >= 6]
sc = te.groupby("subsplit").sample(4, random_state=2026).reset_index(drop=True)
assert not set(zip(sc.input, sc.user)) & used_keys

LABELS = None
emo = pipeline("text-classification", model="SamLowe/roberta-base-go_emotions", top_k=None,
               truncation=True, max_length=128, device=-1)
from common import TO6, TARGET, KB
emb = SentenceTransformer("BAAI/bge-small-en", device="cpu"); kbE = emb.encode(KB, normalize_embeddings=True)
WORD = {"sad": "sadness", "happy": "happiness", "fear": "fear or anxiety", "anger": "anger or frustration",
        "surprise": "surprise or confusion", "love": "affection or care"}

def describe(full, v, dom, gap):
    """Redesigned state description (E2). Fixed BEFORE any Experiment-2 generation."""
    top_label, top_p = max(full.items(), key=lambda x: x[1])
    if top_label == "neutral" or top_p < 0.5:
        return ("No clear emotion was detected in the user's message. Respond to what they actually said, "
                "without assuming or naming a specific emotion."), "uncertain", top_label, top_p
    conf = "high" if top_p >= 0.8 else "moderate"
    srt = sorted(v.items(), key=lambda x: -x[1])
    sec = f", with some {WORD[srt[1][0]]}" if srt[1][1] >= 0.25 else ""
    if gap >= 1.5:
        guide = ("The user appears strongly affected: prioritise warm validation and calm containment, and "
                 "do not rush to advice or silver linings.")
    elif gap >= 0.8:
        guide = "Acknowledge the feeling, then gently invite the user to say more about it."
    else:
        guide = "The user seems fairly settled: respond warmly and naturally, without over-dramatising."
    txt = (f"The user most likely feels {WORD[dom]}{sec} (detector confidence: {conf}). {guide} "
           f"Use this only as background; do not mention it or any analysis to the user.")
    return txt, conf, top_label, top_p

out = []
for r in sc.itertuples():
    full = {d["label"]: d["score"] for d in emo([r.user])[0]}
    top3 = sorted(full.items(), key=lambda x: -x[1])[:3]
    v = {k: 0.0 for k in TARGET}
    for l, p in top3:
        if l in TO6: v[TO6[l]] += p
    t = sum(v.values()); v = {k: round(x / t, 4) if t else 0.0 for k, x in v.items()}
    dom = max(v, key=v.get) if t else "sad"
    gap = round(sum(abs(v[k] - TARGET[k]) for k in TARGET), 4)
    q = emb.encode([f"therapeutic coping strategy for person feeling {dom}"], normalize_embeddings=True)
    rag = [KB[i] for i in np.argsort(-(kbE @ q[0]))[:3]]
    desc, conf, tl, tp = describe(full, v, dom, gap)
    out.append({"id": 1000 + len(out), "ed_emotion": r.subsplit, "situation": r.input, "user": r.user,
                "human_reply": r.reply, "six_de": v, "dominant": dom, "gap": gap, "rag": rag,
                "state_text": desc, "confidence": conf, "top_label": tl, "top_prob": round(tp, 4)})
save_input(out, "exp2_scenarios.json")
print(len(out), "fresh scenarios | confidence:", pd.Series([o["confidence"] for o in out]).value_counts().to_dict())
print(out[0]["user"], "->", out[0]["state_text"])

# ---------------- (2) LoRA data
def pairs(path, n, seed):
    d = load(path)
    d = d[d.reply.str.split().str.len().between(8, 60) & d.reply.str.contains(r"\?") & (d.user.str.split().str.len() >= 4)]
    d = d.drop_duplicates(subset=["user"]).sample(frac=1, random_state=seed).head(n)
    return [{"user": u, "reply": rp, "emotion": e} for u, rp, e in zip(d.user, d.reply, d.subsplit)]
tr = pairs("data/ed_train.parquet", 4000, 42)
va = pairs("data/ed_validation.parquet", 300, 42)
import hashlib, os
for nm, rows in (("exp2_lora_train.jsonl", tr), ("exp2_lora_val.jsonl", va)):
    txt = "".join(json.dumps(x) + "\n" for x in rows); path = f"inputs/{nm}"
    if os.path.exists(path) and open(path).read() != txt:
        open(path + ".new", "w").write(txt); print(f"NOTE: {nm} differs from the shipped copy; written to {path}.new")
    else:
        open(path, "w").write(txt); print(f"{path}: sha256 {hashlib.sha256(txt.encode()).hexdigest()[:16]} (see inputs/exp2_preregistration.md)")
print("LoRA train", len(tr), "val", len(va), "| example:", tr[0])
