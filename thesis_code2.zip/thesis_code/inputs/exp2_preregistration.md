# Experiment 2 - pre-registration (written 2026-11-19 05:37 UTC, before any Experiment-2 generation)

Data: 128 fresh EmpatheticDialogues test conversations (4 per emotion label, seed 2026), disjoint from Experiment 1.
State text, RAG strategies and LoRA data are fixed in exp2_scenarios.json / exp2_lora_*.jsonl (sha256 below).

Conditions (same base model, system prompt, decoding, judge and metrics as Experiment 1):
B0 base | B1 +RAG | E old 6DE | ER old 6DE+RAG | E2 redesigned 6DE | E2R redesigned 6DE+RAG |
AER old LoRA + ER | NER new LoRA + ER | N2R new LoRA + E2R

Redesigned 6DE (E2): natural-language state, given only if the top GoEmotions label is not neutral and has
probability >= 0.5 (otherwise an explicit "no clear emotion" note), confidence wording, gap-dependent guidance
(>=1.5 contain; 0.8-1.5 acknowledge+explore; <0.8 respond naturally), instruction not to mention the analysis.

New LoRA: QLoRA (4-bit base), r=16, alpha=32, dropout 0.05, 7 modules, lr 2e-4, 1 epoch over 4,000 ED train pairs
(reply 8-60 words containing a question), loss on reply tokens only, eval loss on 300 ED validation pairs.

Primary outcome: judge composite = mean(empathy, alignment, relevance). Also reported per dimension, BERTScore vs human
reply, AI-state gap, toxicity, safety, format adherence.
Planned comparisons (paired Wilcoxon, Holm-corrected within each metric):
 H1 E2 vs B0   (does the redesigned 6DE help?)          H2 E2R vs B1 (does it help on top of RAG?)
 H3 E2 vs E    (is the redesign better than the old 6DE?) H4 E vs B0  (replication of Experiment 1)
 H5 NER vs AER (new adapter vs old adapter, same prompt)  H6 N2R vs E2R (does the new adapter help?)
All results will be reported whatever their direction. No further changes after seeing Experiment-2 outputs.
254b4f979141c2c7c3ee3d49c9b46c29ca1b0402f8b5ad38a2834032fbae4889  exp2_scenarios.json
6a7ea3608b4e9a4f19958892d58ef5745d0b2a29e3cd89fc2a40054d701bb0a0  exp2_lora_train.jsonl
62bb37bb79edd5d3b89662cfa89b69c171489dea191ec36a3e78deb3710dde54  exp2_lora_val.jsonl
