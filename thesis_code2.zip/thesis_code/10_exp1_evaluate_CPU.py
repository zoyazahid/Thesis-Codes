"""Step 10 (CPU) - evaluation of Experiment 1 (default: the thesis replies in outputs/exp1_judged.csv).
Per reply: blinded judge scores, BERTScore F1 vs the real human listener reply (RoBERTa-large, rescaled),
toxicity (unitary/toxic-bert), AI-state regulation gap (6DE of the reply vs the balanced target),
format adherence and length. Planned paired comparisons: Wilcoxon signed-rank, Holm-corrected per metric.
Outputs: results/exp1/c3_summary.csv, c3_tests.csv, c3_per_response.csv; figures/exp1/*.png
The automatic metrics of the thesis replies are cached in data_cache/exp1_auto_metrics.parquet."""
import json, os, re, numpy as np, pandas as pd, warnings
warnings.filterwarnings("ignore")
from scipy.stats import wilcoxon
import argparse
ap = argparse.ArgumentParser(); ap.add_argument("--judged", default="outputs/exp1_judged.csv"); ARGS = ap.parse_args()
R = "results/exp1"; F = "figures/exp1"; os.makedirs(R, exist_ok=True); os.makedirs(F, exist_ok=True)
SC = {s["id"]: s for s in json.load(open("inputs/coreg_scenarios.json"))}
df = pd.read_csv(ARGS.judged)
df["response"] = df.response.fillna("").astype(str)
NAMES = {"B0": "Base LLM", "B1": "Base + RAG", "L": "Zero-shot + emotion label", "F": "Few-shot + label",
         "E": "Base + 6DE", "ER": "6DE + RAG (proposed)", "AER": "LoRA + 6DE + RAG (proposed, adapted)"}
ORDER = [c for c in NAMES if c in set(df.condition)]

cache = "data_cache/exp1_auto_metrics.parquet" if ARGS.judged == "outputs/exp1_judged.csv" else f"data_cache/{os.path.basename(ARGS.judged)}.auto.parquet"
if os.path.exists(cache) and len(pd.read_parquet(cache)) == len(df):
    auto = pd.read_parquet(cache)
else:
    from bert_score import score as bscore
    refs = [SC[i]["human_reply"] for i in df.id]
    _, _, f1 = bscore(df.response.tolist(), refs, lang="en", rescale_with_baseline=True, batch_size=32)
    from transformers import pipeline
    tox = pipeline("text-classification", model="unitary/toxic-bert", top_k=None, truncation=True, device=-1)
    tx = [max(d["score"] for d in o if d["label"] == "toxic") for o in tox(df.response.tolist(), batch_size=32)]
    emo = pipeline("text-classification", model="SamLowe/roberta-base-go_emotions", top_k=3,
                   truncation=True, max_length=128, device=-1)
    TO6 = {"sadness": "sad", "grief": "sad", "disappointment": "sad", "remorse": "sad", "embarrassment": "sad",
           "joy": "happy", "excitement": "happy", "amusement": "happy", "gratitude": "happy", "relief": "happy",
           "optimism": "happy", "pride": "happy", "admiration": "happy", "approval": "happy", "fear": "fear",
           "nervousness": "fear", "anger": "anger", "annoyance": "anger", "disgust": "anger",
           "disapproval": "anger", "surprise": "surprise", "realization": "surprise", "confusion": "surprise",
           "curiosity": "surprise", "love": "love", "caring": "love", "desire": "love"}
    T = {"sad": 0.1, "happy": 0.6, "fear": 0.05, "anger": 0.05, "surprise": 0.1, "love": 0.1}
    gaps = []
    for o in emo(df.response.tolist(), batch_size=32):
        v = {k: 0.0 for k in T}
        for d in o:
            if d["label"] in TO6:
                v[TO6[d["label"]]] += d["score"]
        t = sum(v.values()); v = {k: x / t if t else 0 for k, x in v.items()}
        gaps.append(sum(abs(v[k] - T[k]) for k in T) if t else np.nan)
    auto = pd.DataFrame({"bertscore_f1": f1.numpy(), "toxicity": tx, "ai_state_gap": gaps})
    auto.to_parquet(cache)
df = pd.concat([df.reset_index(drop=True), auto], axis=1)
sent = lambda s: [x for x in re.split(r"(?<=[.!?])\s+", s.strip()) if x]
df["n_sentences"] = df.response.apply(lambda s: len(sent(s)))
df["follows_format"] = df.response.apply(lambda s: int(2 <= len(sent(s)) <= 3 and s.strip().endswith("?")))
df["words"] = df.response.str.split().str.len()
df["judge_mean"] = df[["judge_empathy", "judge_alignment", "judge_relevance", "judge_safety"]].mean(axis=1)
df.to_csv(f"{R}/c3_per_response.csv", index=False)

METRICS = ["judge_empathy", "judge_alignment", "judge_relevance", "judge_safety", "judge_mean",
           "bertscore_f1", "ai_state_gap", "toxicity", "follows_format", "words"]
rng = np.random.default_rng(42)
def ci(x):
    x = np.asarray(x, float); x = x[~np.isnan(x)]
    b = [rng.choice(x, len(x)).mean() for _ in range(2000)]
    return x.mean(), np.percentile(b, 2.5), np.percentile(b, 97.5)
summ = []
for c in ORDER:
    d = df[df.condition == c]; row = {"condition": c, "name": NAMES[c], "n": len(d)}
    for m in METRICS:
        mu, lo, hi = ci(d[m]); row[m] = mu; row[m + "_ci"] = f"{lo:.3f}-{hi:.3f}"
    row["judge_parse_rate"] = d.judge_empathy.notna().mean()
    summ.append(row)
summ = pd.DataFrame(summ); summ.to_csv(f"{R}/c3_summary.csv", index=False)

PLANNED = [("B0", "L", "Adding the emotion label"), ("B0", "E", "Adding the 6DE state"),
           ("L", "E", "6DE state vs label only"), ("L", "F", "Few-shot examples"),
           ("B0", "B1", "Adding RAG"), ("E", "ER", "Adding RAG to 6DE"),
           ("B1", "ER", "Adding 6DE to RAG"), ("ER", "AER", "LoRA adaptation")]
PLANNED = [p for p in PLANNED if p[0] in ORDER and p[1] in ORDER]
TESTED = ["judge_empathy", "judge_alignment", "judge_relevance", "judge_safety", "bertscore_f1", "ai_state_gap"]
wide = {m: df.pivot_table(index="id", columns="condition", values=m) for m in TESTED}
tests = []
for m in TESTED:
    ps = []
    for a, b, lab in PLANNED:
        x = wide[m][[a, b]].dropna()
        diff = (x[b] - x[a])
        p = wilcoxon(x[a], x[b], zero_method="zsplit").pvalue if (diff != 0).any() else 1.0
        pos, neg = (diff > 0).sum(), (diff < 0).sum()
        if m == "ai_state_gap":                 # lower gap is better
            pos, neg = neg, pos
        tests.append({"metric": m, "comparison": f"{a} -> {b}", "question": lab, "n": len(x),
                      "mean_A": x[a].mean(), "mean_B": x[b].mean(), "mean_diff": diff.mean(),
                      "B_better_share": (pos / (pos + neg)) if pos + neg else 0.5, "p_raw": p})
T = pd.DataFrame(tests)
for m in TESTED:                                              # Holm correction within each metric
    idx = T[T.metric == m].sort_values("p_raw").index; k = len(idx); run = 0
    for r, i in enumerate(idx):
        run = max(run, min(1.0, T.at[i, "p_raw"] * (k - r))); T.at[i, "p_holm"] = run
T.to_csv(f"{R}/c3_tests.csv", index=False)

import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig, axes = plt.subplots(1, 4, figsize=(15, 4.2), sharey=True)
for ax, m in zip(axes, ["judge_empathy", "judge_alignment", "judge_relevance", "judge_safety"]):
    mu = summ[m].values; lo = [float(s.split("-")[0]) for s in summ[m + "_ci"]]; hi = [float(s.split("-")[1]) for s in summ[m + "_ci"]]
    ax.bar(summ.condition, mu, yerr=np.clip([mu - np.array(lo), np.array(hi) - mu], 0, None), capsize=3,
           color=["#9aa5b1" if c in ("B0", "B1", "L", "F") else "#4C72B0" for c in summ.condition])
    ax.set_title(m.replace("judge_", "").capitalize()); ax.set_ylim(1, 5.2); ax.tick_params(axis="x", labelsize=8)
axes[0].set_ylabel("Blinded judge score (1-5), mean ± 95% CI")
fig.suptitle("Co-regulation conditions (grey = baselines, blue = 6DE-informed)")
fig.tight_layout(); fig.savefig(f"{F}/c3_judge_scores.png", dpi=200)
fig, axes = plt.subplots(1, 2, figsize=(11, 4))
for ax, m, t in [(axes[0], "bertscore_f1", "BERTScore F1 vs human reply (rescaled)"),
                 (axes[1], "ai_state_gap", "AI-state regulation gap (lower = more balanced)")]:
    mu = summ[m].values; lo = [float(s.split("-")[0]) for s in summ[m + "_ci"]]; hi = [float(s.split("-")[1]) for s in summ[m + "_ci"]]
    ax.bar(summ.condition, mu, yerr=np.clip([mu - np.array(lo), np.array(hi) - mu], 0, None), capsize=3, color="#4C72B0"); ax.set_title(t, fontsize=10)
fig.tight_layout(); fig.savefig(f"{F}/c3_auto_metrics.png", dpi=200)
pd.set_option("display.width", 200)
print(summ[["condition", "judge_empathy", "judge_alignment", "judge_relevance", "judge_safety",
            "bertscore_f1", "ai_state_gap", "toxicity", "follows_format", "words", "judge_parse_rate"]].round(3).to_string(index=False))
print(T[["metric", "comparison", "mean_diff", "B_better_share", "p_holm"]].round(4).to_string(index=False))
