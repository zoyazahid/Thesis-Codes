# Human-AI Co-Regulation: Shared Emotional State Balancing with LLM Co-Pilots — code

This folder reproduces every Pipeline B result reported in the thesis (Chapters 3-4).
Run all scripts **from this folder**. Each script name says whether it needs a CPU or a GPU.

| Step | Script | Hardware | What it produces |
|---|---|---|---|
| 0 | `00_download_data_CPU.py` | CPU | DAIC-WOZ checkpoints, GoEmotions, EmpatheticDialogues → `data/` |
| 1 | `01_emotion_recognition_CPU.py` | CPU | Component 1 (emotion recognition) + Component 2 (6DE validation) |
| 2 | `02_depression_detection_CPU.py` | CPU | Component 5: feature blocks, models, held-out test, permutation test, PHQ-8 regression |
| 3 | `03_tfidf_baselines_CPU.py` | CPU | Majority and TF-IDF + logistic regression baselines |
| 4 | `04_nested_cv_CPU.py` | CPU | Nested cross-validation robustness check |
| 5 | `05_llm_phq_features_GPU.py` | GPU (optional) | Zero-shot LLaMA-3 PHQ-8 item scores (first pass) |
| 6 | `06_llm_rescore_failed_GPU.py` | GPU (optional) | Re-scores the 77 sessions whose first answer was incomplete |
| 7 | `07_merge_llm_features_CPU.py` | CPU | Merges both passes into `data_cache/llm_phq_features.csv` |
| 8 | `08_prepare_exp1_scenarios_CPU.py` | CPU (optional) | Rebuilds `inputs/coreg_scenarios.json` (128 conversations) |
| 9 | `09_exp1_generate_and_judge_GPU.py` | GPU (optional) | Experiment 1: 7 conditions + blinded judge |
| 10 | `10_exp1_evaluate_CPU.py` | CPU | Experiment 1 metrics and paired tests |
| 11 | `11_prepare_exp2_CPU.py` | CPU (optional) | Rebuilds the pre-registered Experiment 2 inputs |
| 12 | `12_exp2_train_generate_judge_GPU.py` | GPU (optional) | Experiment 2: new LoRA, 9 conditions + blinded judge |
| 13 | `13_exp2_evaluate_CPU.py` | CPU | Experiment 2 metrics and the six pre-registered hypothesis tests |
| 14 | `14_make_figures_CPU.py` | CPU | Comparison, ablation and 6DE figures |

`expected_results.md` lists the exact numbers each step must print.

## What is included and why

* `inputs/` – the fixed experiment inputs: both scenario sets, the LoRA training/validation data and the
  Experiment 2 pre-registration (with SHA-256 hashes of these files).
* `outputs/` – the exact LLaMA replies and judge scores of the thesis runs (`exp1_judged.csv`,
  `exp2_judged.csv`), the LLaMA PHQ-8 answers and the new adapter's training log.
* `data_cache/` – session-level features and model scores computed during the thesis runs
  (emotion and embedding features, RoBERTa scores on GoEmotions, BERTScore/toxicity of the replies).
  With these caches the CPU steps give **identical** numbers on any machine. Delete a cache file to
  recompute it from scratch (results then agree to about the third decimal, because neural-network
  inference differs very slightly between CPU and GPU builds).

## Reproducibility, honestly stated

* **CPU steps (1-4, 7, 10, 13, 14)** reproduce the thesis numbers exactly with `requirements.txt`.
* **GPU steps (5, 6, 9, 12)** regenerate replies with greedy decoding, but GPU type, 4-bit kernels and
  library versions change some replies slightly. A new run gives very similar, not bit-identical, results;
  evaluate it with `python 10_exp1_evaluate_CPU.py --judged outputs/new_run/exp1_judged.csv`
  (and the same for step 13). GPU steps never overwrite the thesis outputs; they write to `outputs/new_run/`.
* **Pipeline A** (the original v9/v11 notebooks) is not re-run here; its numbers are taken from its run logs.
  The corrected Pipeline A F1 (0.4754) comes from the same notebook with SMOTE moved inside the folds.

## Running in VS Code (or any terminal)

```bash
python -m venv .venv
```
Activate it (Windows PowerShell: `.venv\Scripts\Activate.ps1`; macOS/Linux: `source .venv/bin/activate`), then:
```bash
pip install torch -r requirements.txt
```
Set your Hugging Face token (it needs read access to the private DAIC-WOZ repositories):
```bash
$env:HF_TOKEN = "hf_..."
```
(macOS/Linux: `export HF_TOKEN=hf_...`). Then run the CPU steps in order:
```bash
python 00_download_data_CPU.py
python 01_emotion_recognition_CPU.py
python 07_merge_llm_features_CPU.py
python 02_depression_detection_CPU.py
python 03_tfidf_baselines_CPU.py
python 04_nested_cv_CPU.py
python 10_exp1_evaluate_CPU.py
python 13_exp2_evaluate_CPU.py
python 14_make_figures_CPU.py
```
Step 7 must run before step 2 so that the LLaMA PHQ-8 feature block is included, as in the thesis.
Total CPU time is about 1-1.5 hours, mostly the permutation test and nested CV.

## Running on Google Colab

1. Zip this folder, upload it to Colab (Files panel) and add an `HF_TOKEN` secret (key icon, notebook access on).
2. First cell:
```
!unzip -q thesis_code.zip -d /content && cd /content/thesis_code
%cd /content/thesis_code
!pip install -q -r requirements.txt
!pip uninstall -y -q torchao
import os
from google.colab import userdata
os.environ["HF_TOKEN"] = userdata.get("HF_TOKEN")
```
3. Then run the same commands as above with `!python ...`. The CPU steps do not need a GPU runtime.
4. The GPU steps (9 and 12) need a GPU runtime (T4, L4 or A100). On GPUs below 20 GB the models load in
   4-bit NF4 automatically, as in the thesis runs (Experiment 1 ran on a T4, Experiment 2 on an L4).
   Step 12 reuses the thesis adapter from the Hugging Face repository; set `os.environ["FORCE_TRAIN"] = "1"`
   to train it again.

## Licences and data

DAIC-WOZ is distributed under its own end-user licence and is not included; it is downloaded from the
private repository with your token. GoEmotions and EmpatheticDialogues are public datasets.
