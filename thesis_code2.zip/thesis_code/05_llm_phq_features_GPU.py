"""Step 5 (GPU, optional) - zero-shot LLaMA-3-8B-Instruct PHQ-8 item scoring of every DAIC-WOZ session.
The model reads the participant's answers (first 6,000 tokens) and rates the 8 PHQ-8 symptoms (0-3).
It never sees a label, so the features cannot leak. Output: llm_phq_features.csv (also uploaded to
the HF checkpoint repo; progress is saved every 10 sessions and resumed after a disconnect).
Thesis result of this step: outputs/llm_phq_raw_first_pass.csv (77 answers were in a different JSON
layout and are re-scored by step 6).
Colab: GPU runtime, HF_TOKEN secret with WRITE access, upload this file, then one cell:
    !pip install -q -U transformers accelerate peft huggingface_hub bitsandbytes
    !pip uninstall -y -q torchao
    import os
    from google.colab import userdata
    os.environ["HF_TOKEN"] = userdata.get("HF_TOKEN")
    !python 05_llm_phq_features_GPU.py
"""
import json, os, re, sys
import pandas as pd
import torch

CKPT_REPO = "zoyazahid152/thesis-checkpoints"
OUT = "llm_phq_features.csv"
MODEL = "meta-llama/Meta-Llama-3-8B-Instruct"
MAX_TRANSCRIPT_TOKENS = 6000

def token():
    if os.environ.get("HF_TOKEN"):
        return os.environ["HF_TOKEN"].strip()
    try:
        from google.colab import userdata
        t = userdata.get("HF_TOKEN")
    except Exception as e:
        t = os.environ.get("HF_TOKEN")
        if not t:
            sys.exit(f"Could not read the HF_TOKEN secret ({type(e).__name__}). In the key-icon "
                     "panel, check the name is exactly HF_TOKEN and 'Notebook access' is ON.")
    return t.strip()

TOK = token()
assert torch.cuda.is_available(), "No GPU - stop here so no compute units are wasted."
print("GPU:", torch.cuda.get_device_name(0))

from huggingface_hub import hf_hub_download, HfApi
try:
    who = HfApi(token=TOK).whoami()
    perm = who.get("auth", {}).get("accessToken", {}).get("role", "?")
    print(f"Token OK: logged in as {who['name']} (permission: {perm})")
    if perm == "read":
        sys.exit("This token is READ-only. It must be a WRITE token so results can be uploaded.")
except SystemExit:
    raise
except Exception:
    sys.exit("Hugging Face rejected this token (old/revoked or mistyped). Create a new WRITE "
             "token at huggingface.co/settings/tokens and paste it into the HF_TOKEN secret.")
from transformers import AutoTokenizer, AutoModelForCausalLM

def dl(name):
    return pd.read_csv(hf_hub_download(CKPT_REPO, name, repo_type="model", token=TOK))

tr = dl("clean_transcripts.csv")[["session_id", "text"]]
try:
    te = dl("test_transcripts.csv")[["session_id", "text"]]
except Exception:
    te = pd.DataFrame(columns=["session_id", "text"])
utt = pd.concat([tr, te]).dropna().drop_duplicates()
sessions = sorted(utt.session_id.unique())
print(f"{len(sessions)} sessions to score")

done = pd.DataFrame()
try:
    done = pd.read_csv(OUT) if os.path.exists(OUT) else dl(OUT)
    print(f"Resuming: {len(done)} sessions already scored")
except Exception:
    pass
todo = [s for s in sessions if s not in set(done.get("session_id", []))]

tok = AutoTokenizer.from_pretrained(MODEL, token=TOK)
model = AutoModelForCausalLM.from_pretrained(MODEL, dtype=torch.bfloat16,
                                             device_map="cuda", token=TOK)
model.eval()

ITEMS = ["little interest or pleasure in doing things",
         "feeling down, depressed, or hopeless",
         "trouble falling or staying asleep, or sleeping too much",
         "feeling tired or having little energy",
         "poor appetite or overeating",
         "feeling bad about yourself, or that you are a failure",
         "trouble concentrating on things",
         "moving or speaking slowly, or being fidgety/restless"]
SYSTEM = ("You are a clinical psychologist. You will read the participant's answers from a "
          "semi-structured clinical interview. For each PHQ-8 symptom, estimate how often the "
          "participant experienced it in the last two weeks: 0 = not at all, 1 = several days, "
          "2 = more than half the days, 3 = nearly every day. If there is no evidence, use 0. "
          "Answer ONLY with JSON: {\"items\": [i1, i2, i3, i4, i5, i6, i7, i8]}")

def prompt(text):
    ids = tok(text, add_special_tokens=False).input_ids[:MAX_TRANSCRIPT_TOKENS]
    text = tok.decode(ids)
    items = "\n".join(f"{i+1}. {s}" for i, s in enumerate(ITEMS))
    msgs = [{"role": "system", "content": SYSTEM},
            {"role": "user", "content": f"PHQ-8 symptoms:\n{items}\n\nParticipant answers:\n{text}"}]
    out = tok.apply_chat_template(msgs, add_generation_prompt=True, return_tensors="pt")
    # newer transformers return a dict-like BatchEncoding, older ones a plain tensor
    if not torch.is_tensor(out):
        out = out["input_ids"]
    return out

def parse(s):
    m = re.search(r"\[([\d\s,\.]+)\]", s)
    if not m:
        return [None] * 8
    v = [float(x) for x in re.findall(r"\d+(?:\.\d+)?", m.group(1))][:8]
    v = [min(max(x, 0), 3) for x in v]
    return v + [None] * (8 - len(v))

api = HfApi(token=TOK)
rows = done.to_dict("records") if len(done) else []
for k, sid in enumerate(todo, 1):
    text = " ".join(utt[utt.session_id == sid].text.astype(str))
    ids = prompt(text).to("cuda")
    mask = torch.ones_like(ids)
    with torch.no_grad():
        out = model.generate(input_ids=ids, attention_mask=mask, max_new_tokens=60, do_sample=False,
                             pad_token_id=tok.eos_token_id)
    gen = tok.decode(out[0, ids.shape[1]:], skip_special_tokens=True)
    v = parse(gen)
    row = {"session_id": int(sid), **{f"llm_item{i+1}": v[i] for i in range(8)}}
    row["llm_total"] = sum(x for x in v if x is not None)
    row["raw_llm_output"] = gen.strip().replace("\n", " ")[:300]
    rows.append(row)
    print(f"[{k}/{len(todo)}] {sid}: {v}")
    if k % 10 == 0 or k == len(todo):
        pd.DataFrame(rows).to_csv(OUT, index=False)
        try:   # works only with a WRITE token; a read token just skips this
            api.upload_file(path_or_fileobj=OUT, path_in_repo=OUT,
                            repo_id=CKPT_REPO, repo_type="model")
        except Exception:
            pass
print("DONE -", len(rows), "sessions scored. Downloading", OUT, "...")
try:
    from google.colab import files
    files.download(OUT)
except Exception:
    pass
