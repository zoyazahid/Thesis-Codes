"""D1 majority baseline + D2 TF-IDF logistic regression on DAIC-WOZ (participant text only),
same protocol as improve_results.py: 5x5 repeated stratified CV on train+dev (TF-IDF fitted
inside each fold), threshold from out-of-fold training predictions, single held-out test run."""
import json, numpy as np, pandas as pd
import depression as ir
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import RepeatedStratifiedKFold, cross_validate

utt_tr, utt_te, lab_tr, lab_te, au = ir.load_data()
doc = lambda u: u.groupby("session_id").text.apply(lambda t: " ".join(map(str, t))).reset_index()
tr = doc(utt_tr).merge(lab_tr, on="session_id"); te = doc(utt_te).merge(lab_te, on="session_id")
y, yte = tr.PHQ8_Binary.astype(int).values, te.PHQ8_Binary.astype(int).values
pipe = Pipeline([("tfidf", TfidfVectorizer(ngram_range=(1, 2), min_df=2, max_features=20000, sublinear_tf=True)),
                 ("clf", LogisticRegression(C=1.0, class_weight="balanced", max_iter=5000))])
cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=5, random_state=ir.SEED)
r = cross_validate(pipe, tr.text, y, cv=cv, scoring={"f1": "f1", "bacc": "balanced_accuracy", "auc": "roc_auc"})
m, _ = ir.fit_eval_holdout(pipe, tr.text, y, te.text, yte)
out = {"D1_majority": {"cv_f1": 0.0, "cv_balanced_acc": 0.5, "cv_acc": float(max(y.mean(), 1 - y.mean())),
                       "test_f1": 0.0, "test_acc": float(max(yte.mean(), 1 - yte.mean())), "test_auc": 0.5},
       "D2_tfidf_lr": {"cv_f1": r["test_f1"].mean(), "cv_f1_std": r["test_f1"].std(),
                       "cv_balanced_acc": r["test_bacc"].mean(), "cv_auc": r["test_auc"].mean(),
                       "test_f1": m["f1"], "test_f1_95ci": m["f1_95ci"], "test_auc": m["roc_auc"],
                       "test_balanced_acc": m["balanced_accuracy"], "test_precision": m["precision"],
                       "test_recall": m["recall"], "test_acc": m["accuracy"]}}
json.dump(out, open("results/daic_tfidf_baselines.json", "w"), indent=2, default=float)
print(json.dumps(out, indent=1, default=float))
