"""Nested CV: hyperparameters tuned in an inner 5-fold loop, performance measured on outer folds.
The outer score is an unbiased estimate of the whole tuning procedure."""
import json, numpy as np, pandas as pd, warnings; warnings.filterwarnings("ignore")
import depression as ir
from sklearn.model_selection import GridSearchCV, StratifiedKFold, RepeatedStratifiedKFold, cross_validate
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
utt_tr, utt_te, lab_tr, lab_te, au = ir.load_data()
F = ir.build_features(utt_tr, "traindev").merge(lab_tr, on="session_id")
y = F.PHQ8_Binary.astype(int).values
cols_all = [c for c in F.columns if any(c.startswith(p) for p in ir.BLOCK_PREFIX.values())]
fs = ir.feature_sets(cols_all, has_au=False)
inner = StratifiedKFold(5, shuffle=True, random_state=1)
outer = RepeatedStratifiedKFold(n_splits=5, n_repeats=3, random_state=ir.SEED)
rows = []
for name in ["EMB", "LLM+EMB", "EMB+EMO", "LLM+EMB+EMO+LING"]:
    cols = fs[name]
    for mname, clf, grid in [
        ("LR", LogisticRegression(class_weight="balanced", max_iter=5000), {"clf__C": [0.01, 0.03, 0.1, 0.3, 1]}),
        ("SVM-RBF", SVC(class_weight="balanced", probability=True), {"clf__C": [0.3, 1, 3], "clf__gamma": ["scale", 0.01]})]:
        pipe = ir.make_model(cols, clf, False)
        g = dict(grid)
        if any(c.startswith("emb_") for c in cols):
            g["pre__emb__pca__n_components"] = [16, 32, 64]
        gs = GridSearchCV(pipe, g, scoring="f1", cv=inner, n_jobs=-1)
        r = cross_validate(gs, F[cols], y, cv=outer, scoring={"f1": "f1", "bacc": "balanced_accuracy", "auc": "roc_auc"})
        row = {"features": name, "model": mname, "nested_f1": r["test_f1"].mean(), "nested_f1_std": r["test_f1"].std(),
               "nested_bacc": r["test_bacc"].mean(), "nested_auc": r["test_auc"].mean()}
        rows.append(row); print({k: (round(v, 4) if isinstance(v, float) else v) for k, v in row.items()}, flush=True)
pd.DataFrame(rows).sort_values("nested_f1", ascending=False).to_csv("results/nested_tuning.csv", index=False)
