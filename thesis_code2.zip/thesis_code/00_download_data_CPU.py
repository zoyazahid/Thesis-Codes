"""Step 0 - download all data into data/ (needs HF_TOKEN with access to the private DAIC-WOZ repos).
  * DAIC-WOZ checkpoints: clean_transcripts.csv, clean_au_features.csv (from Pipeline A, Step 1)
  * AVEC 2017 test labels: full_test_split.csv
  * GoEmotions (simplified) train/validation/test
  * EmpatheticDialogues train/validation/test
The test-set utterances are the rows of clean_transcripts.csv that have no label (the 47 AVEC
test sessions); they are written to data/test_transcripts.csv."""
import os, shutil, pandas as pd
from huggingface_hub import hf_hub_download
from common import DATA, HF_CKPT_REPO, HF_DATA_REPO, hf_token

TOK = hf_token()
def get(repo, fname, rtype, out):
    if not os.path.exists(out):
        shutil.copy(hf_hub_download(repo, fname, repo_type=rtype, token=TOK), out)
    print("ok", out)

get(HF_CKPT_REPO, "clean_transcripts.csv", "model", f"{DATA}/clean_transcripts.csv")
get(HF_CKPT_REPO, "clean_au_features.csv", "model", f"{DATA}/clean_au_features.csv")
get(HF_DATA_REPO, "full_test_split.csv", "dataset", f"{DATA}/full_test_split.csv")
for s in ["train", "validation", "test"]:
    get("google-research-datasets/go_emotions", f"simplified/{s}-00000-of-00001.parquet", "dataset", f"{DATA}/go_{s}.parquet")
for s, h in [("train", "9e838d2f771d1f7b"), ("validation", "aeaf2e65c76f3f98"), ("test", "a8c17251ad705ff0")]:
    get("lighteval/empathetic_dialogues", f"data/{s}-00000-of-00001-{h}.parquet", "dataset", f"{DATA}/ed_{s}.parquet")

tr = pd.read_csv(f"{DATA}/clean_transcripts.csv")
te = tr[tr.PHQ8_Binary.isna()][["session_id", "text"]]
te.to_csv(f"{DATA}/test_transcripts.csv", index=False)
print(f"test transcripts: {te.session_id.nunique()} sessions, {len(te)} utterances")
